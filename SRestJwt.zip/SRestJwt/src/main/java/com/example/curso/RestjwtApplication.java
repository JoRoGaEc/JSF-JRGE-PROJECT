package com.example.curso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestjwtApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestjwtApplication.class, args);
	}

}

