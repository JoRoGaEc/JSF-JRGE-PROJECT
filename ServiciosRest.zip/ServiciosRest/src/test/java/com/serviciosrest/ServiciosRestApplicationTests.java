package com.serviciosrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciosRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
