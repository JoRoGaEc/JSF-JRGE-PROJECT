package com.serviciosrest.test;

public class test1 {
    public static void main(String[] args) {
        try {
            System.out.println("A");
            badMethod();
            System.out.println("B");
            
        } catch (Exception e) {
            System.out.println("C");
        }
        finally{
            System.out.println("D");
        }
        
        System.out.println("test2 ");
        System.out.println();
    }
    public static void badMethod(){
        throw new Error();
    }
}
