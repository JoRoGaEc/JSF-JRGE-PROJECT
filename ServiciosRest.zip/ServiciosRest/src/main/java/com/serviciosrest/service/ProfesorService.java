package com.serviciosrest.service;
import com.serviciosrest.entity.*;
import java.util.List;
import java.util.Optional;
public interface ProfesorService {

	public List<Profesor> findAll();
	
	public Profesor findProfesor(Profesor profesor);
	
	public Profesor checkProfesorLogin(Profesor profesor);
	
	public void deleteProfesor(Profesor profesor);
	
	public Profesor updateProfesor(Profesor profesor );
	
	//Aqui utilizando solo el id
	public Optional<Profesor> findProfesorById(Long id);
	
	public void deleteProfesor(Long id);
	
	public Profesor findById(Long id);
	
	public void deleteAllProfesor();
	
	public Profesor findByIdSQL(Long id);
	
	public void save(Profesor profesor);
}
