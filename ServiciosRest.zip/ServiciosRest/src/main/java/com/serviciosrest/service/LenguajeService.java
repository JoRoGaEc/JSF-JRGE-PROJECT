package com.serviciosrest.service;

import java.util.List;

import com.serviciosrest.entity.Lenguaje;

public interface LenguajeService {
	
	public List<Lenguaje> findAll();
	
	public void saveLenguaje(Lenguaje lenguaje);
	
	public abstract Lenguaje findLenguajeById(Long id);
}
