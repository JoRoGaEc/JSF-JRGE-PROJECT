package com.serviciosrest.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.serviciosrest.dao.LenguajeDao;
import com.serviciosrest.entity.Lenguaje;
import com.serviciosrest.service.LenguajeService;

@Service("lenguajeService")
public class LenguajeServiceImpl  implements LenguajeService{

	@Autowired
	@Qualifier("lenguajeRepository")
	private LenguajeDao lenguajeDao;
	
	
	
	@Override
	@Transactional(readOnly =  true)
	public List<Lenguaje> findAll() {
		return (List<Lenguaje>)lenguajeDao.findAll();
	}

	@Override
	public void saveLenguaje(Lenguaje lenguaje) {
		lenguajeDao.save(lenguaje);
		
	}

	@Override
	public Lenguaje findLenguajeById(Long id) {		
		return lenguajeDao.findByIdSQL(id);
	}

	
}
