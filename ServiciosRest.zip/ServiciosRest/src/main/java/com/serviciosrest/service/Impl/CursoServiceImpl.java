package com.serviciosrest.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.serviciosrest.dao.CursoDao;
import com.serviciosrest.entity.Curso;
import com.serviciosrest.service.CursoService;

@Service("cursoServiceImpl")
public class CursoServiceImpl implements CursoService {

	@Autowired
	@Qualifier("cursoReposiotry")
	private CursoDao cursoDao;
		
	@Override
	@Transactional(readOnly =  true)
	public List<Curso> findAll() {		
		return (List<Curso>)cursoDao.findAll();
	}

	@Override
	public void saveCurso(Curso curso) {
		cursoDao.save(curso);
		
	}

	@Override
	public List<Curso> getCursoProfesor(Long id) {
		
		return (List<Curso>)cursoDao.findByProfesorId(id);
	}

}
