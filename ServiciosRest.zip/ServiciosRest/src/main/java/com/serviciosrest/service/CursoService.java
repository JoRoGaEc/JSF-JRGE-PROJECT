package com.serviciosrest.service;

import java.util.List;

import com.serviciosrest.entity.Curso;

public interface CursoService {

	public abstract List<Curso> findAll();
	
	public void saveCurso(Curso curso);
	
	public List<Curso> getCursoProfesor(Long id);
	
	
	
}
