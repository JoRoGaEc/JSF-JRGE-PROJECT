package com.serviciosrest.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.serviciosrest.dao.ProfesorDao;
import com.serviciosrest.entity.Profesor;

@Service("profesorServiceImpl")
public class ProfesorServiceImpl implements ProfesorService{

	@Autowired
	private ProfesorDao profesorDao;
	
	
	
	@Override
	@Transactional(readOnly = true)
	public List<Profesor> findAll() {
		//este metodo se extiende de CRUDRepositorory
		return (List<Profesor>) profesorDao.findAll();
	}

	
	
	@Override
	@Transactional(readOnly = true)
	public Profesor findProfesor(Profesor profesor) {
		return (Profesor) profesorDao.findByEmail(profesor.getEmail());
	}

	@Override
	@Transactional(readOnly = true)
	public Profesor checkProfesorLogin(Profesor profesor) {	
		return (Profesor)profesorDao.findByEmailAndPassword(profesor.getEmail(), profesor.getPassword());
	}

	@Override
	@Transactional
	public void deleteProfesor(Profesor profesor) {
		profesorDao.deleteById(profesor.getId());
		
	}

	@Override
	@Transactional
	public Profesor updateProfesor(Profesor profesor) {
		
		return (Profesor) profesorDao.save(profesor);
	}

	//Ahora metodos en base al ID
	@Override
	@Transactional(readOnly = true)
	public Optional<Profesor> findProfesorById(Long id) {
		
		return (Optional<Profesor>)profesorDao.findById(id);
	}

	@Override
	@Transactional
	public void  deleteProfesor(Long id) {
		profesorDao.deleteById(id);
	}

	@Override
	@Transactional(readOnly = true)
	public Profesor findById(Long id) {		
		return profesorDao.findById(id).orElse(null);
	}

	@Override
	@Transactional(readOnly = true)
	public Profesor findByIdSQL(Long id) {
		return profesorDao.findByIdSQL(id);
	}


	@Override
	@Transactional
	public void save(Profesor profesor) {
		profesorDao.save(profesor);
		
	}


	@Override
	@Transactional
	public void deleteAllProfesor() {
		profesorDao.deleteAll();
		
	}

	
}
