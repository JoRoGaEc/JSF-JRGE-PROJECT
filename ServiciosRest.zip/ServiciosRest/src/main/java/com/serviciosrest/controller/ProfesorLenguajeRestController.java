package com.serviciosrest.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.serviciosrest.entity.Lenguaje;
import com.serviciosrest.entity.Profesor;
import com.serviciosrest.model.ProfesorLenguaje;
import com.serviciosrest.service.LenguajeService;
import com.serviciosrest.service.ProfesorService;

@RestController
@RequestMapping("/api")
public class ProfesorLenguajeRestController {

	@Autowired
	@Qualifier("lenguajeService")
	private LenguajeService lenguajeService;
	
	@Autowired
	@Qualifier("profesorServiceImpl")
	private ProfesorService profesorService;
	
	
	@PostMapping("/lenguajes_profesor")
	public ResponseEntity<?> listaLenguajeProfesor(@RequestBody Profesor profesor){
		Profesor profesorDb =  profesorService.findById(profesor.getId());
		if(profesorDb != null ) {
			Collection<Lenguaje> listaLenguajes = profesorDb.getLenguajes();
			if(listaLenguajes != null ) {
				return new ResponseEntity<>(listaLenguajes, HttpStatus.OK);
			}
		}
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	 }
	
	@PostMapping("/save_lenguaje_profesor")
	public ResponseEntity<?> saveLenguajeProfesor(@RequestBody ProfesorLenguaje profesorLenguaje){
		Profesor profesorDb  =  profesorService.findById(profesorLenguaje.getProfesor().getId());
		if(profesorDb != null) {
			Lenguaje lenguageDb =  lenguajeService.findLenguajeById(profesorLenguaje.getLenguaje().getId());
			profesorDb.addLenguaje(lenguageDb);
			profesorService.save(profesorDb);
			return new ResponseEntity<Void>(HttpStatus.CREATED);
		}
		
		return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		
	}
}
