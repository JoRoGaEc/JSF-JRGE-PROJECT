package com.serviciosrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import com.serviciosrest.entity.*;
import com.serviciosrest.mapper.Mapper;
import com.serviciosrest.model.ProfesorModel;
import com.serviciosrest.service.ProfesorService;

@RestController
@RequestMapping("/api")    //ahora le diremos como va comenzar este endpoint
public class ProfesorRestController {
	
	@Autowired
	@Qualifier("profesorServiceImpl")
	private ProfesorService profesorService;
	
	
	@GetMapping("/profesores")//este complementa el EndPoint
	@ResponseStatus(HttpStatus.OK)
	public List<Profesor> getProfesores(){
		return profesorService.findAll();
	}
	
	@PostMapping("/find_profesor") //Aqui mandaremos en el body el id
	public ResponseEntity<?> findProfesor(@RequestBody Profesor profesor){
		Profesor profesorDb =  profesorService.findProfesor(profesor); //Este metodo va a la base de datos y busca por el email
		if(profesorDb!= null) {
			return new ResponseEntity<>(profesorDb, HttpStatus.OK);
		}else {
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
		
	}
	
	
	@PostMapping("/sign_up")
	public ResponseEntity<Void> addProfesor(@RequestBody Profesor profesor){
		if(profesorService.findProfesor(profesor) == null) {
			profesorService.save(profesor);
			return new ResponseEntity<Void>(HttpStatus.CREATED);
		}else {
			return new ResponseEntity<Void>(HttpStatus.CONFLICT); //409
		}
	}
	

	@PutMapping("/update/{id}") //con {id} especificamos una URL específica , el nombre corresponderá con value="id"
	public ResponseEntity<?> updateProfesor(@PathVariable(value="id")Long id,  @RequestBody Profesor profesor){ 
		Profesor profesorDb = null;
		profesorDb = profesorService.findById(id);
		if(profesorDb != null) {
			profesorDb.setEmail(profesor.getEmail()); //profesor es el que recibimos como parametro 
			profesorDb.setNombre(profesor.getNombre());
			//actualizaer la Base de datos
			profesorService.updateProfesor(profesorDb);
			
			return new ResponseEntity<>(profesorDb, HttpStatus.OK);
		}else {
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
	}
	
	
	//CASO ESPECIAL
	@PutMapping("/update_sql") //con {id} especificamos una URL específica , el nombre corresponderá con value="id"
	public ResponseEntity<?> updateProfesorSql(@RequestBody Profesor profesor){
		//este metodo requiere que el id venga en el cuerpo
		//Esto no es lo normal pedo se puede dar
		Profesor profesorDb = null;
		profesorDb = profesorService.findByIdSQL(profesor.getId());
		if(profesorDb != null) {
			profesorDb.setEmail(profesor.getEmail()); //profesor es el que recibimos como parametro 
			profesorDb.setNombre(profesor.getNombre());
			//actualizaer la Base de datos
			profesorService.updateProfesor(profesorDb);
			
			return new ResponseEntity<>(profesorDb, HttpStatus.OK);
		}else {
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<Void> deleteProfesor(@PathVariable(value="id")Long id){
		profesorService.deleteProfesor(id);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	
	@DeleteMapping("/delete")
	public ResponseEntity<Void> deleteAllProfesores(){
		profesorService.deleteAllProfesor();
		return new ResponseEntity<Void>(HttpStatus.OK);
	}
	
	
	//Un delete con un POST Mapping no es lo normal, pero se puede dar en la vida real 
	//CASO ESPECIAL
	@PostMapping("/delete_post")
	public ResponseEntity<Void> deleteProfesorPost(@RequestBody Profesor profesor){
		if(profesorService.findProfesor(profesor)!= null) {
			profesorService.deleteProfesor(profesor);
			return  new ResponseEntity<Void>(HttpStatus.OK);
		}
		return  new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
	}
	
	
	
	//METODO PARA HACER EL LOGIN
	@PostMapping("/login")
	public ResponseEntity<?> loginProfesor(@RequestBody Profesor profesor){
		Profesor profesorDb =  profesorService.checkProfesorLogin(profesor);		
		if(profesorDb !=null) {
			Profesor  profesorE = profesorDb;
			ProfesorModel profesorModel = null;
			profesorModel =  Mapper.convertirProfesorToModel(profesorE);
			
			return new ResponseEntity<>(profesorModel , HttpStatus.OK); //Devuelve un 200
		}else {
			return new ResponseEntity<Void>(HttpStatus.NOT_FOUND);
		}
	}
	
	

}
