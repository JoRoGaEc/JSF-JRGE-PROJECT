package com.serviciosrest.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.serviciosrest.entity.Lenguaje;

@Repository("lenguajeRepository")
public interface LenguajeDao extends CrudRepository<Lenguaje, Long>{

	@Query("Select l from Lenguaje l where l.id = ?1")
	public Lenguaje findByIdSQL(Long id);
	
}
