package com.serviciosrest.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.serviciosrest.entity.Profesor;

//El Dao es el Objeto de Acceso a Datos 
//Ventajas la interfaz posee metodos bases
public interface ProfesorDao  extends CrudRepository<Profesor, Long>{
	
	public Profesor findByEmail(String Email);
	
	public Profesor findByEmailAndPassword(String email, String password);
	
	public Optional<Profesor> findById(Long id);
	
	@Query("select p from Profesor p where p.id =?1")
	public Profesor findByIdSQL(Long id);//este parametro corresponde con el ?1 de arriba
	   
	
}
