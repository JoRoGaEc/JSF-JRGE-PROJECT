package com.serviciosrest.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.serviciosrest.entity.Curso;

@Repository("cursoReposiotry")
public interface CursoDao extends CrudRepository<Curso, Long>{
	
	public List<Curso> findByProfesorId(Long id);
	
}
