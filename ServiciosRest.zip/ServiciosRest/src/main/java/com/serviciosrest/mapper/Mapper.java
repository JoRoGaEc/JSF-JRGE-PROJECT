package com.serviciosrest.mapper;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.serviciosrest.entity.Profesor;
import com.serviciosrest.model.ProfesorModel;

@Component("mapper")
public class Mapper {

	public static List<ProfesorModel> convertirLista(List<Profesor> profesores ){
		List<ProfesorModel> mProfesores = new ArrayList<ProfesorModel>();
		for(Profesor profesor : profesores) {
			mProfesores.add(new ProfesorModel(profesor));
		}
		return mProfesores;
	}
	
	public static ProfesorModel convertirProfesorToModel(Profesor profesor) {
		return new ProfesorModel(profesor);
	}
}
