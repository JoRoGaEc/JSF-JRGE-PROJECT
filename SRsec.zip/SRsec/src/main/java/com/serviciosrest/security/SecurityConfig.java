package com.serviciosrest.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;

@EnableWebSecurity
public class SecurityConfig extends WebSecurityConfigurerAdapter{
	//En autenticacion basica el cliente debe enviar en la cabecera Http las credenciales, en cada solicitud
	
	//Para decir el modo en que se autentican los usuarios
	@Autowired
	public void configureGlobalSecurity(AuthenticationManagerBuilder auth)throws Exception{
		//Aqui indicamos los usuarios que pueden accceder a esos recursos
		auth.inMemoryAuthentication().withUser("roberto").password("0000").roles("ADMIN");
		auth.inMemoryAuthentication().withUser("user").password("user").roles("USER");

	}
	
	//el metodo siguiente nos permite la configuracion de las URL
	@Override
	protected void configure(HttpSecurity http) throws Exception{
		http.csrf().disable().authorizeRequests()
		.antMatchers("/todos_profesores_public").permitAll()     //esto es por si corresponde con el endPoint que estamos usando 
		.antMatchers("/todos_profesores_admin").hasRole("ADMIN")
		.antMatchers("/todos_profesores_user/**").hasRole("USER")
		.and()
		.httpBasic();
	}
	
	@SuppressWarnings("deprecation")
	@Bean
	public static NoOpPasswordEncoder passwordEncoder() {
		return (NoOpPasswordEncoder) NoOpPasswordEncoder.getInstance();
	}
	
}
