package com.serviciosrest.service;

import java.util.List;

import com.serviciosrest.entity.Profesor;

public interface ProfesorService {

	public abstract List<Profesor> listarProfesores(); 
}
