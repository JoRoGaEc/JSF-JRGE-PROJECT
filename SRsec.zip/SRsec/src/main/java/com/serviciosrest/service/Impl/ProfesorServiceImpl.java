package com.serviciosrest.service.Impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.serviciosrest.dao.ProfesorDao;
import com.serviciosrest.entity.Profesor;
import com.serviciosrest.service.ProfesorService;

@Service("profesorService")
public class ProfesorServiceImpl implements ProfesorService{

	@Autowired
	@Qualifier("profesorDao")
	private ProfesorDao profesorDao;
	
	
	@Override
	public List<Profesor> listarProfesores() {
		return (List<Profesor>) profesorDao.findAll();
	}

	
}
