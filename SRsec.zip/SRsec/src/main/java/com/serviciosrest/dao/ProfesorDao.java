package com.serviciosrest.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.serviciosrest.entity.*;

@Repository("profesorDao")
public interface ProfesorDao extends CrudRepository<Profesor, Long>{

}
