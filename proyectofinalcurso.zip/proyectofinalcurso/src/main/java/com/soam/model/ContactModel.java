package com.soam.model;

public class ContactModel {
	private int id;
	private String primerNombre;
	private String ultimoNombre;
	private String telefono;
	private String ciudad;


	
	
	public ContactModel(int id, String primerNombre, String ultimoNombre, String telefono, String ciudad) {
		super();
		this.id = id;
		this.primerNombre = primerNombre;
		this.ultimoNombre = ultimoNombre;
		this.telefono = telefono;
		this.ciudad = ciudad;
	}

	public ContactModel() {
		super();
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getPrimerNombre() {
		return primerNombre;
	}


	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}


	public String getUltimoNombre() {
		return ultimoNombre;
	}


	public void setUltimoNombre(String ultimoNombre) {
		this.ultimoNombre = ultimoNombre;
	}


	public String getTelefono() {
		return telefono;
	}


	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}


	public String getCiudad() {
		return ciudad;
	}


	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	@Override
	public String toString() {
		return "ContactModel [id=" + id + ", primerNombre=" + primerNombre + ", ultimoNombre=" + ultimoNombre
				+ ", telefono=" + telefono + ", ciudad=" + ciudad + "]";
	}
	
	
	
}
