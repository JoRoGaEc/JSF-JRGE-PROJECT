package com.soam.component;

import org.springframework.stereotype.Component;

import com.soam.entity.Contact;
import com.soam.model.ContactModel;

@Component("contactConverter")
public class ContactConverter {

	public Contact covertContactModel2Contact(ContactModel contactModel) {
		Contact contact =  new Contact();
		contact.setPrimerNombre(contactModel.getPrimerNombre());
		contact.setUltimoNombre(contactModel.getUltimoNombre());
		contact.setTelefono(contactModel.getTelefono());
		contact.setCiudad(contactModel.getCiudad());
		contact.setId(contactModel.getId());
		return contact;
	}
	
	public ContactModel contact2ContactModel(Contact contact) {
		ContactModel contactModel = new ContactModel();
		contactModel.setPrimerNombre(contact.getPrimerNombre());
		contactModel.setUltimoNombre(contact.getUltimoNombre());
		contactModel.setTelefono(contact.getTelefono());
		contactModel.setCiudad(contact.getCiudad());
		contactModel.setId(contact.getId());
		return contactModel;
	}
	
}
