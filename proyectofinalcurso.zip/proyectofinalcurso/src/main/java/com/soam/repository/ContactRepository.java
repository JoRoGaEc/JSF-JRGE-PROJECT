package com.soam.repository;

import org.springframework.stereotype.Repository;

import com.soam.entity.Contact;

import java.io.Serializable;

import org.springframework.data.jpa.repository.JpaRepository;

@Repository("contactRepository") //Para que adopte la funcionalidad de Jpa debemos extender de una clase
public interface ContactRepository  extends JpaRepository<Contact,Serializable>{
	
	public abstract Contact findById(int id);
	
	
}
