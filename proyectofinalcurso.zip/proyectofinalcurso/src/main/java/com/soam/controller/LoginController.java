package com.soam.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.soam.constant.ViewConstant;

@Controller //No le vamos a agregar un request mapping porque..
public class LoginController {


	private static final Logger LOG=  LoggerFactory.getLogger(LoginController.class);
	
	@GetMapping("/login")
	public String showLoginForm(Model model,
								@RequestParam(name="error",required = false) String error,
								@RequestParam(name="logout", required=false) String logout ) {
		LOG.info("METHOD: " + "showLoginForm() -- PARAMS: error="  + error + ", Logout =  " + logout);
		model.addAttribute("error", error);
		model.addAttribute("logout", logout); //Estos son para que se puedan rellenar en la vista	
		LOG.info("Returning to login view ");
		return ViewConstant.LOGIN_FORM; //Usamos la clase de Constantes
	}
	
	@GetMapping({"/loginsuccess", "/"})
	public String loginCheck() {
		LOG.info("METHOD : loginCheck()");
		return "redirect:/contacts/showcontacts"; 
		
		
		
	}
	
	
	
	
}
