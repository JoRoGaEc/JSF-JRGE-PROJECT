package com.soam.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;



@Component("requestTimeInterceptor")
public class RequestTimeInterceptor extends HandlerInterceptorAdapter{

	//para calcular el tiempo y desplegarlo en el LOG
	private static final Logger logger = LoggerFactory.getLogger(RequestTimeInterceptor.class);
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		//Con esto lograresmo que antes de entrar al metodo, se guarde en la peticion el tiempo de la peticion en ese momento
		request.setAttribute("startTime", System.currentTimeMillis());
		return true;
	}
	@Override
	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		//Se ejecuta antes de entrar en el metodo del controlador
		long startTime =  (long)request.getAttribute("startTime");
		logger.info("REQUEST URL " + request.getRequestURL().toString() + " "  + " in:  " + (System.currentTimeMillis()- startTime) + "ms");
		
		
	
	}




}
