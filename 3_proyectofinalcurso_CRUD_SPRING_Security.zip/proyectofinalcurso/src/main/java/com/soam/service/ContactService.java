package com.soam.service;


import java.util.List;

import com.soam.entity.Contact;
import com.soam.model.ContactModel;

public interface ContactService {

	public abstract ContactModel addContact(ContactModel model);
	
	public abstract List<ContactModel> listAllContacts(); //Para recuperar el listado de todos los contactos
	//a traves de esta interfaz accederemos a la implementacion y nos comunicaremos con el repositorio
	
	public abstract Contact findContactById(int id); //estos pueden ser cualquier nombre de metodo 
	
	public abstract void removeContact(int id); //Este puede ser cualquier nombre de metodo 
		
	public abstract ContactModel findContactByIdModel(int id); //estos pueden ser cualquier nombre de metodo 
}
