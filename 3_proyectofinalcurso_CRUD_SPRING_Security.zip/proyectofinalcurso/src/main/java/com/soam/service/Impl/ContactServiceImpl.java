package com.soam.service.Impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import com.soam.component.ContactConverter;
import com.soam.entity.Contact;
import com.soam.model.ContactModel;
import com.soam.repository.ContactRepository;
import com.soam.service.ContactService;

@Service("contactServiceImpl")
public class ContactServiceImpl implements ContactService{

	
	@Autowired
	@Qualifier("contactRepository")
	private ContactRepository contactRepository;
	
	@Autowired
	@Qualifier("contactConverter")
	private ContactConverter contactConverter;
	
	
	@Override
	public ContactModel addContact(ContactModel contactModel) {
		Contact contact  = contactRepository.save(contactConverter.covertContactModel2Contact(contactModel));
		/*
		 * 
		 * AQUI PUEDE IR MUCHA LOGICA DE NEGOCIO
		 */		
		return contactConverter.contact2ContactModel(contact);
	}


	@Override
	public List<ContactModel> listAllContacts() {
		List<Contact> contacts = contactRepository.findAll();
		List<ContactModel> contactsModel = new ArrayList<ContactModel>();
		for(Contact c : contacts ) {
			contactsModel.add(contactConverter.contact2ContactModel(c));
		}
		
		return contactsModel;
	}


	@Override
	public Contact findContactById(int id) {
		return contactRepository.findById(id);
	}
	
	public ContactModel findContactByIdModel(int id) {
		return contactConverter.contact2ContactModel(findContactById(id)); 
	}


	@Override
	public void removeContact(int id) {
		Contact contact= findContactById(id);
		if(null != contact) {
			contactRepository.delete(contact);
		}else {
			
		}
		
		
	}
	
}
