package com.soam.constant;

public class ViewConstant {
	
	public static final String CONTACT_FORM = "contactform";
	public static final String CONTACTS_FORM = "contacts";
	public static final String LOGIN_FORM = "login"; 
	
}
