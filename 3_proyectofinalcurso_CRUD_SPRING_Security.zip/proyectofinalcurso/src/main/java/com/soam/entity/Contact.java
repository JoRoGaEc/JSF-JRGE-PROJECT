package com.soam.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "contact")
public class Contact {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="id")
	private int id;
	
	@Column(name="primernombre")
	private String primerNombre;
	
	@Column(name="ultimonombre")
	private String ultimoNombre;
	
	@Column(name="telefono")
	private String telefono;
	
	@Column(name="ciudad")
	private String ciudad;

	public Contact(int id, String primerNombre, String ultimoNombre, String telefono, String ciudad) {
		super();
		this.id = id;
		this.primerNombre = primerNombre;
		this.ultimoNombre = ultimoNombre;
		this.telefono = telefono;
		this.ciudad = ciudad;
	}

	public Contact() {
		super();
		// constructor vacio
	}

	public String getPrimerNombre() {
		return primerNombre;
	}

	public void setPrimerNombre(String primerNombre) {
		this.primerNombre = primerNombre;
	}

	public String getUltimoNombre() {
		return ultimoNombre;
	}

	public void setUltimoNombre(String ultimoNombre) {
		this.ultimoNombre = ultimoNombre;
	}

	public String getTelefono() {
		return telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	

}
