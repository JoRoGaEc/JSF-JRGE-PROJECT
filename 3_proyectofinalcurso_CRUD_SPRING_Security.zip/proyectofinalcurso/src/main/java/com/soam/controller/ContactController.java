package com.soam.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.soam.constant.ViewConstant;
import com.soam.model.ContactModel;
import com.soam.service.ContactService;


@Controller
@RequestMapping("/contacts")
public class ContactController {

	
	//OJO SI COLOCAMOS ALGUN METODO COMO PRIVATE EL PREAUTHORIZE NO FUNCIONA
	private static final Logger LOG=  LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	@Qualifier("contactServiceImpl")
	private ContactService contactService;
	
	
	@GetMapping("/cancel")
	public String cancel() {
		return "redirect:/contacts/showcontacts";
	}
	
	@PreAuthorize("hasRole('ROLE_USER')") //esto lo puedo hacer gracias a la anotacion @EnableGlobalMethodSecurity(prePostEnabled = true)
	@GetMapping("/contactform") //este formulario va gestionar un modelo, por ello se lo pasaremos vacio
	public String redirectContactForm(@RequestParam(name="id", required=false) int id,
										Model model) {
	    ContactModel  contactModel = new ContactModel(); //esto por si es para crear 
		if(id != 0) {
		     contactModel = contactService.findContactByIdModel(id); //esto en caso de que si traiga un id y significa que lo que se quiere es editar
		}
		
		model.addAttribute("contactModel", contactModel ); //par enviarlo a la vista para que se llene
		//Manejamos el model en lugar de la ENTIDAD
		return ViewConstant.CONTACT_FORM;
	}
	
	@PostMapping("/addcontact") //Luego recibimos el Model que le pasamos en el metodo anterior 
	public String addContact(@ModelAttribute(name="contactModel") ContactModel contactModel, 
			Model model) {//contactModel se corresponde con el th:object que colocamos en la vista
		//aqui seguimos manejando el Modelo en lugar de la Entidad
			
		LOG.info("METHOD: " + "addContact() -- PARAMS: contactModel="   + 	contactModel );
		if(null != contactService.addContact(contactModel)) {
			model.addAttribute("result",1);	
		} //Al servicio le pasamos el contactModel
		else {
			model.addAttribute("result",1);	
		}
		return "redirect:/contacts/showcontacts";  //ViewConstant.CONTACTS_FORM
	
	  }
	
	@GetMapping("/showcontacts")
	public ModelAndView  showContacts() {
		ModelAndView mav=  new ModelAndView(ViewConstant.CONTACTS_FORM);
		mav.addObject("contacts",contactService.listAllContacts());
		return mav;
	}
	
	@GetMapping("/removecontact")
	public ModelAndView removeContact(@RequestParam(name="id", required = true) int id) {
		contactService.removeContact(id);
		return showContacts();
	}

}
