package com.sga.datos;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.sga.domain.Persona;

//Debe ser un EJB para que pueda inyectarse el EntityManager de JPA el persistense UNIT
@Stateless
public class PersonaDaoImpl implements PersonaDao{

	@PersistenceContext(unitName="primePU")
	EntityManager em;
	
	
	@SuppressWarnings("unchecked")
	@Override
	public List<Persona> findAllPersonas() {
		// TODO Auto-generated method stub
		
		return em.createNamedQuery("Persona.findAll").getResultList();
		
	}

	@Override
	public Persona findPersonaById(Persona persona) {
		// TODO Auto-generated method stub
		return em.find(Persona.class, persona.getIdPersona());
	}

	@Override
	public Persona findPersonByEmail(Persona persona) {
		// TODO Auto-generated method stub
		Query q= em.createQuery("from Persona p where p.email =: email");
		q.setParameter("email", persona.getEmail());
		
		return (Persona) q.getSingleResult();
	}

	@Override
	public void insertPersona(Persona persona) {
		em.persist(persona);
		
	}

	@Override
	public void updatePersona(Persona persona) {
		em.merge(persona);
		
	}

	@Override
	public void deletePersona(Persona persona) {
		// TODO Auto-generated method stub
		em.remove(em.merge(persona));
		
	}

}
