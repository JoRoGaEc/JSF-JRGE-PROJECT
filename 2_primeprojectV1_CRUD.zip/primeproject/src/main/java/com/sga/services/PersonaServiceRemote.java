package com.sga.services;

import java.util.List;

import javax.ejb.Remote;

import com.sga.domain.Persona;

@Remote
public interface PersonaServiceRemote {
	//para trabajr luego en la capa de datos
	public List<Persona> listaPersonas();
	
	public Persona encontrarPersonaPorId(Persona persona);
	
	public Persona encontrarPersonaPorEmail(Persona persona);
	
	public void registrarPersona(Persona persona);
	
	public void modificarPersona(Persona persona);
	
	public void eliminarPersona(Persona persona);
	
}
