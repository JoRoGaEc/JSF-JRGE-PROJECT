package com.sga.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.PersonaDao;
import com.sga.domain.Persona;

@Stateless
public class PersonaServiceImpl implements PersonaServiceRemote, PersonaService{

	@Inject //Esta inyeccion la hace el servidor de de aplicaciones 
	private PersonaDao personaDao;
	
	@Resource  
	private SessionContext contexto; //Esto lo posee el contenedor de wildfly
	
	
	@Override
	public List<Persona> listaPersonas() {

		return personaDao.findAllPersonas();
	}

	@Override
	public Persona encontrarPersonaPorId(Persona persona) {
		// TODO Auto-generated method stub
		return personaDao.findPersonaById(persona);
	}

	@Override
	public Persona encontrarPersonaPorEmail(Persona persona) {
		// TODO Auto-generated method stub
		return personaDao.findPersonByEmail(persona);
	}

	@Override
	public void registrarPersona(Persona persona) {
		// TODO Auto-generated method stub
		personaDao.insertPersona(persona);
	}

	@Override
	public void modificarPersona(Persona persona) {
		try {
		personaDao.updatePersona(persona);
		}catch(Throwable t) {
			//Con la variable de contexto vamos a poder rollback en la transaccion
			//si ocurre algun valor
			contexto.setRollbackOnly();
			t.printStackTrace(System.out);
		}
	}

	@Override
	public void eliminarPersona(Persona persona) {
		personaDao.deletePersona(persona);
		
	}

}
