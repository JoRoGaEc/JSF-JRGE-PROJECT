package com.sga.web;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.RowEditEvent;

import com.sga.domain.Persona;
import com.sga.services.PersonaService;

@Named("personaBean")
@RequestScoped
public class PersonaBean {
	static Logger logger = LogManager.getLogger();
	//Inyectaremos el Servicio de persona con la notacion CDI
	@Inject
	private PersonaService personaService;
	
	//Atributo PersonaSeleccionada de tipo Persona para saber si alguno de los registros ha sido seleccionado
	private Persona personaSeleccionada; //Este es el POJO que se ha mapeado	
	List<Persona> personas;
	
	
	public PersonaBean() {
		//Constructror vacio
		logger.debug("Acabo de crear PersonaBean");
	}
	
	@PostConstruct
	public void inicializar() {
		//iniciamos las variables, en este caso el listado de personas
		personas = personaService.listaPersonas();
		personaSeleccionada = new Persona();
		logger.debug("\nimpresion de personas antes de enviarse a la vista");
		for(Persona p: personas) {
			logger.debug("Persona " + p.toString());
		}
		
	}
	
	public void editListener(RowEditEvent event) {
		Persona persona = (Persona) event.getObject(); //Primefaces nos devolvera un objeto 
		personaService.modificarPersona(persona);
	}

	public Persona getPersonaSeleccionada() {
		return personaSeleccionada;
	}

	public void setPersonaSeleccionada(Persona personaSeleccionada) {
		this.personaSeleccionada = personaSeleccionada;
	}

	public List<Persona> getPersonas() {
		return personas;
	}

	public void setPersonas(List<Persona> personas) {
		this.personas = personas;
	}
	
    public void agregarPersona(){
        this.personaService.registrarPersona(personaSeleccionada);
        this.personas.add(personaSeleccionada);
        this.personaSeleccionada = null;
    }
    
    public void eliminarPersona(){
        this.personaService.eliminarPersona(personaSeleccionada);
        this.personas.remove(this.personaSeleccionada);
        this.personaSeleccionada = null;
    }
    
    public void reiniciarPersonaSeleccionada(){
        this.personaSeleccionada = new Persona();
    }
	
	
}
