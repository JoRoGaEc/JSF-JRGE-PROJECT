package com.soam.converter;

import org.springframework.stereotype.Component;

import com.soam.entity.Curso;
import com.soam.model.CursoModel;

@Component("cursoConverter")
public class CursoConverter {

	//METODO PARA CONVERTIR ENTITY >  MODEL
	public CursoModel entity2model(Curso curso) {
		CursoModel cursoModel = new CursoModel();
		cursoModel.setNombre(curso.getNombre());
		cursoModel.setDescripcion(curso.getDescripcion());
		cursoModel.setPrecio(curso.getPrecio());
		cursoModel.setHoras(curso.getHoras());
		return cursoModel;
	}
	
	
	
	
	//METODO PARA CONVERTIR MODEL A ENTITY
	public Curso model2entity(CursoModel cursoModel) {
		Curso curso = new Curso();
		curso.setNombre(cursoModel.getNombre());
		curso.setDescripcion(cursoModel.getDescripcion());
		curso.setHoras(cursoModel.getHoras());
		curso.setPrecio(cursoModel.getPrecio());		
		return curso;
	}
	
}
