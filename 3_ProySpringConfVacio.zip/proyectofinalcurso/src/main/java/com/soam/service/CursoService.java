package com.soam.service;

import java.util.List;
import com.soam.entity.Curso;
public interface CursoService {
	
	public abstract List<Curso> listAllCursos();
	public abstract Curso agregerCurso(Curso curso);
	public abstract void eliminarCurso(Curso curso);
	public abstract Curso modificarCurso(Curso curso);
}
