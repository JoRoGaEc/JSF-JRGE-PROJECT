package com.soam.component;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

@Component("exampleComponent")
public class ExampleComponent {
	static final Logger log = LoggerFactory.getLogger(ExampleComponent.class);
	
	public void sayHello() {
		log.info("HELLO FROM EXAMPLE COMPONENT");
		
	}
}
