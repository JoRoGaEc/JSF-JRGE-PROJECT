package com.soam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoamprojApplicationTests {

	@Test
	void contextLoads() {
	}

}
