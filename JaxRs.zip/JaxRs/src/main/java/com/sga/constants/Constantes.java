package com.sga.constants;

public class Constantes {

	public static final String UNIDAD_PERSISTENCIA = "jaxRSPU";
	
}
