package com.sga.services;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.inject.Inject;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.sga.datos.PersonaDao;
import com.sga.domain.Persona;

@Path("/personas")
@Stateless
public class PersonaServiceRS {

	@Inject
	private PersonaDao personaService;
	
	@GET//este es el metodo por default por eso no le vamos a especificar nada 
	@Produces({MediaType.APPLICATION_XML , MediaType.APPLICATION_JSON})
	public List<Persona> listarPersona(){
		return personaService.listarPersonas();
	}
	
	@GET
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Path("{id}") //hace referencia al path /personas/algun id
	public Persona enontrarPersonaPorId(@PathParam("id")Long id) {
		return personaService.buscarPorId(id);
	}
	
	@POST
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON}) //Producira un respuesta si se agrego correctamente una persona
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})//porque vamos a recibir un objeto de tipo persona
	@Path("/agregar")
	public Response agregarPersona(Persona persona) {
		try {
			personaService.insertar(persona);
			return Response.ok().entity(persona).build();
		} catch (Exception e) {
			e.printStackTrace(System.out);
			return Response.status(Status.INTERNAL_SERVER_ERROR).build();
		}

	}
	
	@PUT
	@Produces({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
	@Path("/actualizar/{id}")
	public Response actualizarPersona(@PathParam("id") Long id , Persona personaModificada) {
			try {
			Persona persona =  personaService.buscarPorId(id);
			if(persona != null) {
				personaService.actualizarPersona(personaModificada);
				return Response.ok().entity(personaModificada).build();
			}else {
				return Response.status(Status.NOT_FOUND).build();
			}
			}catch(Exception e) {
				e.printStackTrace(System.out);
				return Response.status(Status.INTERNAL_SERVER_ERROR).build();
			}
	}
	
	
	@DELETE
	@Path("/delete/{id}")
	public Response eliminarPersonaPorId(@PathParam("id") Long id) {
		try {
		personaService.delete(id);
		return Response.ok().build();
	   }catch(Exception e) {
		   e.printStackTrace(System.out);
		   return Response.status(404).build();
	   }
		
	}
	
	
	
	
	 
}
