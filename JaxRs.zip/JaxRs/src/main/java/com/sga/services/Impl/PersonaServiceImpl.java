package com.sga.services.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.PersonaDao;
import com.sga.domain.Persona;
import com.sga.services.PersonaService;
import com.sga.services.PersonaServiceRemote;

@Stateless
public class PersonaServiceImpl implements PersonaService, PersonaServiceRemote{

	@Inject
	private PersonaDao personaDaoImpl;
	
	@Override
	public void insertar(Persona persona) {
		personaDaoImpl.insertar(persona);
		
	}

	@Override
	public List<Persona> listarPersonas() {
		
		return personaDaoImpl.listarPersonas();
	}

	@Override
	public Persona buscarPorId(Long id) {
		return personaDaoImpl.buscarPorId(id);
	}

	@Override
	public void actualizarPersona(Persona persona) {
		personaDaoImpl.actualizarPersona(persona);
		
	}

	@Override
	public void delete(Long id) {
		personaDaoImpl.delete(id);
		
	}

}
