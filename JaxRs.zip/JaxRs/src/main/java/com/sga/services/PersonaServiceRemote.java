package com.sga.services;

import java.util.List;

import javax.ejb.Remote;

import com.sga.domain.Persona;

@Remote
public interface PersonaServiceRemote {
    
	public abstract void insertar(Persona persona);
	
	public abstract List<Persona> listarPersonas();
	
	public abstract Persona buscarPorId(Long id);
	
	public abstract void actualizarPersona(Persona persona);
	
	public abstract void delete(Long id);
    
}
