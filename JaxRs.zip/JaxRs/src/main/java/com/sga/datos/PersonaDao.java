package com.sga.datos;

import java.util.List;

import com.sga.domain.Persona;

public interface PersonaDao {

	public abstract void insertar(Persona persona);
	
	public abstract List<Persona> listarPersonas();
	
	public abstract Persona buscarPorId(Long id);
	
	public abstract void actualizarPersona(Persona persona);
	
	public abstract void delete(Long id);
}
