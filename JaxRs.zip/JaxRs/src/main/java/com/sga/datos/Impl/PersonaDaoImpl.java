package com.sga.datos.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.sga.constants.Constantes;
import com.sga.datos.PersonaDao;
import com.sga.domain.Persona;

@Stateless
public class PersonaDaoImpl implements PersonaDao{

	@PersistenceContext(unitName = Constantes.UNIDAD_PERSISTENCIA)
	EntityManager em;

	@Override
	public void insertar(Persona persona) {
		em.persist(persona);
		
	}

	@Override
	public List<Persona> listarPersonas() {
		Query q =  em.createQuery("select p from Persona p");
		return q.getResultList();
	}

	@Override
	public Persona buscarPorId(Long id) {
		return em.find(Persona.class, id);
	}

	@Override
	public void actualizarPersona(Persona persona) {
		em.merge(persona);
		
	}

	@Override
	public void delete(Long id) {
		Query q =  em.createQuery("delete from Persona p where p.id = ?1");
		q.setParameter(1, id);
		q.executeUpdate();
	}
	
	
}
