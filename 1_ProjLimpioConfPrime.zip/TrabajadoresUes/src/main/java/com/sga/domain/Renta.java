package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the renta database table.
 * 
 */
@Entity
@NamedQuery(name="Renta.findAll", query="SELECT r FROM Renta r")
public class Renta implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_RENTA")
	private int idRenta;

	@Column(name="ANIO_RENTA")
	private String anioRenta;

	@Column(name="MES_RENTA")
	private String mesRenta;

	@Column(name="MONTO_RENTA")
	private float montoRenta;

	//bi-directional many-to-one association to Empleado
	@ManyToOne
	@JoinColumn(name="ID_EMPLEADO")
	private Empleado empleado;

	public Renta() {
	}

	public int getIdRenta() {
		return this.idRenta;
	}

	public void setIdRenta(int idRenta) {
		this.idRenta = idRenta;
	}

	public String getAnioRenta() {
		return this.anioRenta;
	}

	public void setAnioRenta(String anioRenta) {
		this.anioRenta = anioRenta;
	}

	public String getMesRenta() {
		return this.mesRenta;
	}

	public void setMesRenta(String mesRenta) {
		this.mesRenta = mesRenta;
	}

	public float getMontoRenta() {
		return this.montoRenta;
	}

	public void setMontoRenta(float montoRenta) {
		this.montoRenta = montoRenta;
	}

	public Empleado getEmpleado() {
		return this.empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

}