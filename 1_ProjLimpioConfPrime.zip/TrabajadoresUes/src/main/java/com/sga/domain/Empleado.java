package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the empleado database table.
 * 
 */
@Entity
@NamedQuery(name="Empleado.findAll", query="SELECT e FROM Empleado e")
public class Empleado implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_EMPLEADO")
	private int idEmpleado;

	private String apellido;

	private String nit;

	private String nombre;

	//bi-directional many-to-one association to BienestarMagisterial
	@OneToMany(mappedBy="empleado")
	private List<BienestarMagisterial> bienestarMagisterials;

	//bi-directional many-to-one association to TipoEmpleado
	@ManyToOne
	@JoinColumn(name="ID_TIPO_EMPLEADO")
	private TipoEmpleado tipoEmpleado;

	//bi-directional many-to-one association to Isss
	@OneToMany(mappedBy="empleado")
	private List<Isss> issses;

	//bi-directional many-to-one association to Pago
	@OneToMany(mappedBy="empleado")
	private List<Pago> pagos;

	//bi-directional many-to-one association to Renta
	@OneToMany(mappedBy="empleado")
	private List<Renta> rentas;

	//bi-directional many-to-one association to Seguro
	@OneToMany(mappedBy="empleado")
	private List<Seguro> seguros;

	//bi-directional many-to-one association to Totale
	@OneToMany(mappedBy="empleado")
	private List<Total> totales;

	public Empleado() {
	}

	public int getIdEmpleado() {
		return this.idEmpleado;
	}

	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}

	public String getApellido() {
		return this.apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getNit() {
		return this.nit;
	}

	public void setNit(String nit) {
		this.nit = nit;
	}

	public String getNombre() {
		return this.nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public List<BienestarMagisterial> getBienestarMagisterials() {
		return this.bienestarMagisterials;
	}

	public void setBienestarMagisterials(List<BienestarMagisterial> bienestarMagisterials) {
		this.bienestarMagisterials = bienestarMagisterials;
	}

	public BienestarMagisterial addBienestarMagisterial(BienestarMagisterial bienestarMagisterial) {
		getBienestarMagisterials().add(bienestarMagisterial);
		bienestarMagisterial.setEmpleado(this);

		return bienestarMagisterial;
	}

	public BienestarMagisterial removeBienestarMagisterial(BienestarMagisterial bienestarMagisterial) {
		getBienestarMagisterials().remove(bienestarMagisterial);
		bienestarMagisterial.setEmpleado(null);

		return bienestarMagisterial;
	}

	public TipoEmpleado getTipoEmpleado() {
		return this.tipoEmpleado;
	}

	public void setTipoEmpleado(TipoEmpleado tipoEmpleado) {
		this.tipoEmpleado = tipoEmpleado;
	}

	public List<Isss> getIssses() {
		return this.issses;
	}

	public void setIssses(List<Isss> issses) {
		this.issses = issses;
	}

	public Isss addIsss(Isss isss) {
		getIssses().add(isss);
		isss.setEmpleado(this);

		return isss;
	}

	public Isss removeIsss(Isss isss) {
		getIssses().remove(isss);
		isss.setEmpleado(null);

		return isss;
	}

	public List<Pago> getPagos() {
		return this.pagos;
	}

	public void setPagos(List<Pago> pagos) {
		this.pagos = pagos;
	}

	public Pago addPago(Pago pago) {
		getPagos().add(pago);
		pago.setEmpleado(this);

		return pago;
	}

	public Pago removePago(Pago pago) {
		getPagos().remove(pago);
		pago.setEmpleado(null);

		return pago;
	}

	public List<Renta> getRentas() {
		return this.rentas;
	}

	public void setRentas(List<Renta> rentas) {
		this.rentas = rentas;
	}

	public Renta addRenta(Renta renta) {
		getRentas().add(renta);
		renta.setEmpleado(this);

		return renta;
	}

	public Renta removeRenta(Renta renta) {
		getRentas().remove(renta);
		renta.setEmpleado(null);

		return renta;
	}

	public List<Seguro> getSeguros() {
		return this.seguros;
	}

	public void setSeguros(List<Seguro> seguros) {
		this.seguros = seguros;
	}

	public Seguro addSeguro(Seguro seguro) {
		getSeguros().add(seguro);
		seguro.setEmpleado(this);

		return seguro;
	}

	public Seguro removeSeguro(Seguro seguro) {
		getSeguros().remove(seguro);
		seguro.setEmpleado(null);

		return seguro;
	}

	public List<Total> getTotales() {
		return this.totales;
	}

	public void setTotales(List<Total> totales) {
		this.totales = totales;
	}

	public Total addTotale(Total totale) {
		getTotales().add(totale);
		totale.setEmpleado(this);

		return totale;
	}

	public Total removeTotale(Total totale) {
		getTotales().remove(totale);
		totale.setEmpleado(null);

		return totale;
	}

}