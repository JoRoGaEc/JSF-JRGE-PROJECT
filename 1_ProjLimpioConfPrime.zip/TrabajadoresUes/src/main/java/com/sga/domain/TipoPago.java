package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tipo_pago database table.
 * 
 */
@Entity
@Table(name="tipo_pago")
@NamedQuery(name="TipoPago.findAll", query="SELECT t FROM TipoPago t")
public class TipoPago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_TIPO_PAGO")
	private int idTipoPago;

	@Column(name="CODIGO_TIPO_PAGO")
	private String codigoTipoPago;

	@Column(name="NOMBRE_TIPO_PAGO")
	private String nombreTipoPago;

	//bi-directional many-to-one association to Pago
	@OneToMany(mappedBy="tipoPago")
	private List<Pago> pagos;

	public TipoPago() {
	}

	public int getIdTipoPago() {
		return this.idTipoPago;
	}

	public void setIdTipoPago(int idTipoPago) {
		this.idTipoPago = idTipoPago;
	}

	public String getCodigoTipoPago() {
		return this.codigoTipoPago;
	}

	public void setCodigoTipoPago(String codigoTipoPago) {
		this.codigoTipoPago = codigoTipoPago;
	}

	public String getNombreTipoPago() {
		return this.nombreTipoPago;
	}

	public void setNombreTipoPago(String nombreTipoPago) {
		this.nombreTipoPago = nombreTipoPago;
	}

	public List<Pago> getPagos() {
		return this.pagos;
	}

	public void setPagos(List<Pago> pagos) {
		this.pagos = pagos;
	}

	public Pago addPago(Pago pago) {
		getPagos().add(pago);
		pago.setTipoPago(this);

		return pago;
	}

	public Pago removePago(Pago pago) {
		getPagos().remove(pago);
		pago.setTipoPago(null);

		return pago;
	}

}