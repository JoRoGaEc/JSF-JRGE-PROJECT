package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the totales database table.
 * 
 */
@Entity
@Table(name="totales")
@NamedQuery(name="Totale.findAll", query="SELECT t FROM Total t")
public class Total implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_TOTALES")
	private int idTotales;

	@Column(name="AGUINALDO_EXENTO")
	private float aguinaldoExento;

	@Column(name="AGUINALDO_GRAVADO")
	private float aguinaldoGravado;

	@Column(name="TOTAL_BONOS")
	private float totalBonos;

	@Column(name="TOTAL_DEVENGADO")
	private float totalDevengado;

	@Column(name="TOTAL_GRATIFICACIONES")
	private float totalGratificaciones;

	@Column(name="TOTAL_ISR")
	private float totalIsr;

	@Column(name="TOTAL_ISSS")
	private float totalIsss;

	@Column(name="TOTAL_SEGURO_VIDA")
	private float totalSeguroVida;

	//bi-directional many-to-one association to Empleado
	@ManyToOne
	@JoinColumn(name="ID_EMPLEADO")
	private Empleado empleado;

	public Total() {
	}

	public int getIdTotales() {
		return this.idTotales;
	}

	public void setIdTotales(int idTotales) {
		this.idTotales = idTotales;
	}

	public float getAguinaldoExento() {
		return this.aguinaldoExento;
	}

	public void setAguinaldoExento(float aguinaldoExento) {
		this.aguinaldoExento = aguinaldoExento;
	}

	public float getAguinaldoGravado() {
		return this.aguinaldoGravado;
	}

	public void setAguinaldoGravado(float aguinaldoGravado) {
		this.aguinaldoGravado = aguinaldoGravado;
	}

	public float getTotalBonos() {
		return this.totalBonos;
	}

	public void setTotalBonos(float totalBonos) {
		this.totalBonos = totalBonos;
	}

	public float getTotalDevengado() {
		return this.totalDevengado;
	}

	public void setTotalDevengado(float totalDevengado) {
		this.totalDevengado = totalDevengado;
	}

	public float getTotalGratificaciones() {
		return this.totalGratificaciones;
	}

	public void setTotalGratificaciones(float totalGratificaciones) {
		this.totalGratificaciones = totalGratificaciones;
	}

	public float getTotalIsr() {
		return this.totalIsr;
	}

	public void setTotalIsr(float totalIsr) {
		this.totalIsr = totalIsr;
	}

	public float getTotalIsss() {
		return this.totalIsss;
	}

	public void setTotalIsss(float totalIsss) {
		this.totalIsss = totalIsss;
	}

	public float getTotalSeguroVida() {
		return this.totalSeguroVida;
	}

	public void setTotalSeguroVida(float totalSeguroVida) {
		this.totalSeguroVida = totalSeguroVida;
	}

	public Empleado getEmpleado() {
		return this.empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

}