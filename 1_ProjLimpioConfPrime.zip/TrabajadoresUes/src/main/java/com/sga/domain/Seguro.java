package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the seguro database table.
 * 
 */
@Entity
@NamedQuery(name="Seguro.findAll", query="SELECT s FROM Seguro s")
public class Seguro implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_SEGURO")
	private int idSeguro;

	@Column(name="ANIO_SEGURO")
	private float anioSeguro;

	@Column(name="MES_SEGURO")
	private float mesSeguro;

	@Column(name="MONTO_SEGURO")
	private float montoSeguro;

	//bi-directional many-to-one association to Empleado
	@ManyToOne
	@JoinColumn(name="ID_EMPLEADO")
	private Empleado empleado;

	//bi-directional many-to-one association to TipoPension
	@ManyToOne
	@JoinColumn(name="ID_TIPO_PENSION")
	private TipoPension tipoPension;

	public Seguro() {
	}

	public int getIdSeguro() {
		return this.idSeguro;
	}

	public void setIdSeguro(int idSeguro) {
		this.idSeguro = idSeguro;
	}

	public float getAnioSeguro() {
		return this.anioSeguro;
	}

	public void setAnioSeguro(float anioSeguro) {
		this.anioSeguro = anioSeguro;
	}

	public float getMesSeguro() {
		return this.mesSeguro;
	}

	public void setMesSeguro(float mesSeguro) {
		this.mesSeguro = mesSeguro;
	}

	public float getMontoSeguro() {
		return this.montoSeguro;
	}

	public void setMontoSeguro(float montoSeguro) {
		this.montoSeguro = montoSeguro;
	}

	public Empleado getEmpleado() {
		return this.empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

	public TipoPension getTipoPension() {
		return this.tipoPension;
	}

	public void setTipoPension(TipoPension tipoPension) {
		this.tipoPension = tipoPension;
	}

}