package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the bienestar_magisterial database table.
 * 
 */
@Entity
@Table(name="bienestar_magisterial")
@NamedQuery(name="BienestarMagisterial.findAll", query="SELECT b FROM BienestarMagisterial b")
public class BienestarMagisterial implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_BIENESTAR")
	private int idBienestar;

	@Column(name="ANIO_BIENESTAR")
	private float anioBienestar;

	@Column(name="MES_BIENESTAR")
	private float mesBienestar;

	@Column(name="MONTO_BIENESTAR")
	private float montoBienestar;

	//bi-directional many-to-one association to Empleado
	@ManyToOne
	@JoinColumn(name="ID_EMPLEADO")
	private Empleado empleado;

	public BienestarMagisterial() {
	}

	public int getIdBienestar() {
		return this.idBienestar;
	}

	public void setIdBienestar(int idBienestar) {
		this.idBienestar = idBienestar;
	}

	public float getAnioBienestar() {
		return this.anioBienestar;
	}

	public void setAnioBienestar(float anioBienestar) {
		this.anioBienestar = anioBienestar;
	}

	public float getMesBienestar() {
		return this.mesBienestar;
	}

	public void setMesBienestar(float mesBienestar) {
		this.mesBienestar = mesBienestar;
	}

	public float getMontoBienestar() {
		return this.montoBienestar;
	}

	public void setMontoBienestar(float montoBienestar) {
		this.montoBienestar = montoBienestar;
	}

	public Empleado getEmpleado() {
		return this.empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

}