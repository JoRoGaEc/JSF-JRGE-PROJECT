package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the isss database table.
 * 
 */
@Entity
@NamedQuery(name="Isss.findAll", query="SELECT i FROM Isss i")
public class Isss implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_ISSS")
	private int idIsss;

	@Column(name="ANIO_ISSS")
	private String anioIsss;

	@Column(name="MES_ISSS")
	private String mesIsss;

	@Column(name="MONTO_ISSS")
	private float montoIsss;

	//bi-directional many-to-one association to Empleado
	@ManyToOne
	@JoinColumn(name="ID_EMPLEADO")
	private Empleado empleado;

	public Isss() {
	}

	public int getIdIsss() {
		return this.idIsss;
	}

	public void setIdIsss(int idIsss) {
		this.idIsss = idIsss;
	}

	public String getAnioIsss() {
		return this.anioIsss;
	}

	public void setAnioIsss(String anioIsss) {
		this.anioIsss = anioIsss;
	}

	public String getMesIsss() {
		return this.mesIsss;
	}

	public void setMesIsss(String mesIsss) {
		this.mesIsss = mesIsss;
	}

	public float getMontoIsss() {
		return this.montoIsss;
	}

	public void setMontoIsss(float montoIsss) {
		this.montoIsss = montoIsss;
	}

	public Empleado getEmpleado() {
		return this.empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

}