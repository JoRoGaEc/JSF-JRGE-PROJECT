package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the pago database table.
 * 
 */
@Entity
@NamedQuery(name="Pago.findAll", query="SELECT p FROM Pago p")
public class Pago implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_PAGO")
	private int idPago;

	@Column(name="ANIO_MONTO")
	private String anioMonto;

	@Column(name="MES_MONTO")
	private String mesMonto;

	@Column(name="MONTO_PAGO")
	private float montoPago;

	//bi-directional many-to-one association to Empleado
	@ManyToOne
	@JoinColumn(name="ID_EMPLEADO")
	private Empleado empleado;

	//bi-directional many-to-one association to TipoPago
	@ManyToOne
	@JoinColumn(name="ID_TIPO_PAGO")
	private TipoPago tipoPago;

	public Pago() {
	}

	public int getIdPago() {
		return this.idPago;
	}

	public void setIdPago(int idPago) {
		this.idPago = idPago;
	}

	public String getAnioMonto() {
		return this.anioMonto;
	}

	public void setAnioMonto(String anioMonto) {
		this.anioMonto = anioMonto;
	}

	public String getMesMonto() {
		return this.mesMonto;
	}

	public void setMesMonto(String mesMonto) {
		this.mesMonto = mesMonto;
	}

	public float getMontoPago() {
		return this.montoPago;
	}

	public void setMontoPago(float montoPago) {
		this.montoPago = montoPago;
	}

	public Empleado getEmpleado() {
		return this.empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

	public TipoPago getTipoPago() {
		return this.tipoPago;
	}

	public void setTipoPago(TipoPago tipoPago) {
		this.tipoPago = tipoPago;
	}

}