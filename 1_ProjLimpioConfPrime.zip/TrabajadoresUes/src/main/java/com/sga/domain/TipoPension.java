package com.sga.domain;

import java.io.Serializable;
import javax.persistence.*;
import java.util.List;


/**
 * The persistent class for the tipo_pension database table.
 * 
 */
@Entity
@Table(name="tipo_pension")
@NamedQuery(name="TipoPension.findAll", query="SELECT t FROM TipoPension t")
public class TipoPension implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="ID_TIPO_PENSION")
	private int idTipoPension;

	@Column(name="CODIGO_TIPO_PENSION")
	private String codigoTipoPension;

	@Column(name="NOMBRE_TIPO_PENSION")
	private String nombreTipoPension;

	//bi-directional many-to-one association to Seguro
	@OneToMany(mappedBy="tipoPension")
	private List<Seguro> seguros;

	public TipoPension() {
	}

	public int getIdTipoPension() {
		return this.idTipoPension;
	}

	public void setIdTipoPension(int idTipoPension) {
		this.idTipoPension = idTipoPension;
	}

	public String getCodigoTipoPension() {
		return this.codigoTipoPension;
	}

	public void setCodigoTipoPension(String codigoTipoPension) {
		this.codigoTipoPension = codigoTipoPension;
	}

	public String getNombreTipoPension() {
		return this.nombreTipoPension;
	}

	public void setNombreTipoPension(String nombreTipoPension) {
		this.nombreTipoPension = nombreTipoPension;
	}

	public List<Seguro> getSeguros() {
		return this.seguros;
	}

	public void setSeguros(List<Seguro> seguros) {
		this.seguros = seguros;
	}

	public Seguro addSeguro(Seguro seguro) {
		getSeguros().add(seguro);
		seguro.setTipoPension(this);

		return seguro;
	}

	public Seguro removeSeguro(Seguro seguro) {
		getSeguros().remove(seguro);
		seguro.setTipoPension(null);

		return seguro;
	}

}