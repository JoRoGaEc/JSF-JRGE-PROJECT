package com.sga.datos;

import java.util.List;

import com.sga.domain.Pago;

public interface PagosDao {

	public abstract void save(Pago pago);
	
	public abstract List<Pago> pagosPorEmpleado(int id, String mes , int anio , int tipoPago);
	
	public abstract void eliminarPago(int id);
}
