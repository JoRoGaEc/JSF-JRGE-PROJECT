 package com.sga.datos;

import com.sga.domain.PermisoPago;


public interface PermisoTipoDao {
	
	public abstract PermisoPago recuperarPermisoTipo(int id);
	
}
