package com.sga.datos.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.sga.constant.*;
import com.sga.datos.PagosDao;
import com.sga.domain.Pago;

@Stateless
public class PagosDaoImpl implements PagosDao{

	@PersistenceContext(unitName = ConstantesPath.UNIDAD_PERSISTENCIA)
	private EntityManager em;

	@Override
	public void save(Pago pago) {
		em.persist(pago);
		
	}

	@Override
	public List<Pago> pagosPorEmpleado(int id, String mes, int anio, int tipoPago) {
		Query q = em.createQuery("select p from Pago p inner join p.tipoPago tp "
									  + " inner join p.empleado e "
									  + "where e.id = ?1 and p.mes = ?2 and p.anio = ?3 and tp.id = ?4 "
									  + "order by p.fechaIngreso desc ");
		q.setParameter(1, id)
		 .setParameter(2, mes)
		 .setParameter(3, anio)
		 .setParameter(4, tipoPago);
		
		return q.getResultList();
	}

	@Override
	public void eliminarPago(int id) {
		Pago p1 =  new Pago(id);
		Query q=  em.createQuery("delete from Pago p where p.id =  ?1");
		q.setParameter(1, id);
		q.executeUpdate();
		
	}
	

	
}
