
package com.sga.datos.Impl;

import java.util.List;
import javax.persistence.ParameterMode;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.hibernate.annotations.Target;

import com.sga.constant.ConstantesPath;
import com.sga.datos.ReportesDao;
import com.sga.domain.Empleado;
import javax.persistence.*;
@Stateless
public class ReportesDaoImpl implements ReportesDao{

	@PersistenceContext(unitName = ConstantesPath.UNIDAD_PERSISTENCIA)	
	EntityManager em;
	
	@Override
	public List<Empleado> calcularTotalesDao(int anio) {	
        try
        {
            StoredProcedureQuery storedProcedure = em.createStoredProcedureQuery("calcularTotales")
                    .registerStoredProcedureParameter(0 , Integer.class , ParameterMode.IN);             
            storedProcedure .setParameter(0, anio);
            storedProcedure.execute();
        } 
        catch (Exception e) {
            e.printStackTrace();
            
        }
		Query q =  em.createQuery("select e from Empleado e join fetch e.tipoEmpleado te join fetch e.informe i join fetch e.tipoPension tp");	
		
		return q.getResultList();
	}

	@Override
	public Empleado empleadoParaBoleta(int id) {
		Query q =  em.createQuery("select e from Empleado e where e.id = ?1");
		      q.setParameter(1, id);
		return (Empleado)q.getSingleResult();
	}


}
