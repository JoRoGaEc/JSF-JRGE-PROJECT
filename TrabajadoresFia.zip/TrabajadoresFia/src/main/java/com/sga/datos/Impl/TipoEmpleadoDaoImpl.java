package com.sga.datos.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.sga.constant.ConstantesPath;
import com.sga.datos.TipoEmpleadoDao;
import com.sga.domain.Empleado;
import com.sga.domain.TipoEmpleado;

@Stateless
public class TipoEmpleadoDaoImpl implements TipoEmpleadoDao{

	static Logger LOG = LogManager.getLogger();
	@PersistenceContext(unitName = ConstantesPath.UNIDAD_PERSISTENCIA)
	EntityManager em;
	
	
	
	@Override
	public List<TipoEmpleado> listarTipoEmpleados() {
		Query q = em.createQuery("SELECT te FROM TipoEmpleado te ");		
		return q.getResultList();
	}

	@Override
	public TipoEmpleado buscarTipoEmpleadoById(TipoEmpleado tipoEmpleado) {
	   Query q=  em.createQuery("select te from TipoEmpleado te inner join te.permisos p "
	   							+ "	where te.id = ?1");
	   	q.setParameter(1, tipoEmpleado.getId());
	   	return (TipoEmpleado) q.getResultList().stream().findFirst().orElse(null);
	}

	@Override
	public void insertarTipoEmpleado(TipoEmpleado tipoEmpleado) {
		em.persist(tipoEmpleado);
		
	}

	@Override
	public void actualizarEmpleado(TipoEmpleado tipoEmpleado) {
		em.merge(tipoEmpleado);
		
	}

	@Override
	public void eliminarTipoEmpleado(TipoEmpleado tipoEmpleado) {
		em.remove(em.merge(tipoEmpleado));
		
	}
	
	@Override
	public TipoEmpleado buscarTipoEmpleadoByCodigo(String codigo) {
	   LOG.debug("codigo " + codigo);
	   Query q=  em.createQuery("select te from TipoEmpleado te where te.codigo = ?1");
	   	q.setParameter(1, codigo);
	   	return (TipoEmpleado) q.getSingleResult();
	}

}
