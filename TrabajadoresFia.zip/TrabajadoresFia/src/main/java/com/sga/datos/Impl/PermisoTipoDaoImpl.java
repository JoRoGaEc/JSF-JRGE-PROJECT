package com.sga.datos.Impl;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import com.sga.constant.ConstantesPath;
import com.sga.datos.PermisoTipoDao;
import com.sga.domain.PermisoPago;

@Stateless
public class PermisoTipoDaoImpl implements PermisoTipoDao{

	@PersistenceContext(unitName = ConstantesPath.UNIDAD_PERSISTENCIA)
	private EntityManager em;
	
	@Override
	public PermisoPago recuperarPermisoTipo(int id) {		
		return em.find(PermisoPago.class, id);
	}

	
}
