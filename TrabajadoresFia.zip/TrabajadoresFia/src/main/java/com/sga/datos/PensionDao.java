package com.sga.datos;

import com.sga.domain.Empleado;
import com.sga.domain.Pension;
import com.sga.domain.TipoPension;

public interface PensionDao {

	public int guardarDatosPension(Pension pension) ;
	
}
