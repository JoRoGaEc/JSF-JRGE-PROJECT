package com.sga.datos;

import java.util.List;

import com.sga.domain.TipoPago;

public interface TipoPagoDao {

	public abstract TipoPago buscarTipoPago(int id);
}
