package com.sga.datos.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import com.sga.constant.ConstantesPath;
import com.sga.datos.TipoPagoDao;
import com.sga.domain.TipoPago;

@Stateless
public class TipoPagoDaoImpl implements TipoPagoDao{

	@PersistenceContext(unitName = ConstantesPath.UNIDAD_PERSISTENCIA)
	private EntityManager em;
	
	@Override
	public TipoPago buscarTipoPago(int id) {
		Query  q = em.createQuery("select tp  from TipoPago tp  where tp.id = ?1");
		q.setParameter(1, id);
		return (TipoPago)q.getSingleResult();
	}

}
