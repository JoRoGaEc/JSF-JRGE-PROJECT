package com.sga.test;

public class TestTipoDato {

	public static void main(String[] args) {
		String i = "6";
		System.out.println("TIPO DE DATO: " + i.getClass().getSimpleName());
		
	}

}
