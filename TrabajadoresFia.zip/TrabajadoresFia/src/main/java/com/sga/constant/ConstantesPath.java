package com.sga.constant;

public class ConstantesPath {

	public static final String UNIDAD_PERSISTENCIA = "primePU";
}
