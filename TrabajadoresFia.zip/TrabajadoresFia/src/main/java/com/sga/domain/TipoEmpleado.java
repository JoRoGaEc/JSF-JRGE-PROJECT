package com.sga.domain;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name="tipoempleado")
public class TipoEmpleado {

	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="tipo")
	private String tipo;
	
	@Column(name="codigo")
	private String codigo;
	

	//OJO CON SOLO QUE ESTE ESTE EN EAGER NO ELIMINA LOS EMPLEADOS, PODEMOS HACER UNA PRUEBA
	@OneToMany(mappedBy = "tipoEmpleado",cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Empleado> empleados;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinTable(
			name = "tipoempleado_permisopago", 
			uniqueConstraints = { @UniqueConstraint(columnNames = { "tipoempleado_id","permisopago_id" }) }, 
			joinColumns = @JoinColumn(name = "tipoempleado_id"), 
			inverseJoinColumns = @JoinColumn(name = "permisopago_id")
	)
	private List<PermisoPago> permisos;
	

	public TipoEmpleado() {
		super();
	}

	public TipoEmpleado(int id, String tipo, String codigo) {
		super();
		this.id = id;
		this.tipo = tipo;
		this.codigo = codigo;
	}

	public TipoEmpleado(int id) {
		this.id = id;
	}
	
	public TipoEmpleado (String id) {
		this.id = Integer.parseInt(id);
	}
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}

	public List<PermisoPago> getPermisos() {
		return permisos;
	}

	public void setPermisos(List<PermisoPago> permisos) {
		this.permisos = permisos;
	}

	@Override
	public String toString() {
		return "TipoEmpleado [id=" + id + ", tipo=" + tipo + ", codigo=" + codigo ;
	}

    
	
	
}
