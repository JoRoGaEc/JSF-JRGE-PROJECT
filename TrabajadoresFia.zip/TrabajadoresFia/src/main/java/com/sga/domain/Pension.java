package com.sga.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="pension")
@NamedQuery(name="Pension.findAll", query="SELECT p FROM Pension p")
public class Pension {

	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
		
	@OneToOne(mappedBy = "montoPension", fetch = FetchType.LAZY)
	private Pago pago; //pago es como se le coloco que en la Clase Pago
	
	@Column(name = "monto")
	private float monto=0.00F;

	
	public Pension() {
		super();
	}

	public Pension(int id, int periodo, Empleado empleado, TipoPension tipoPension) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Pago getPago() {
		return pago;
	}

	public void setPago(Pago pago) {
		this.pago = pago;
	}

	public float getMonto() {
		return monto;
	}

	public void setMonto(float monto) {
		this.monto = monto;
	}
	
	
	
	
}
