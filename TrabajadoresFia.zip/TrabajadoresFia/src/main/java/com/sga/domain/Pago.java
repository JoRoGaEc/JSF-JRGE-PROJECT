package com.sga.domain;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.Table;

@Entity
@Table(name = "pago")
public class Pago {
	
	@Id
	@Column
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="monto")
	private float monto;
	
	@Column(name="mes")
	private String mes;
	
	@Column(name="anio")
	private int anio;
	
	@Column(name="fecha_ingreso")
	private Date fechaIngreso;
	
	@PrePersist
	public void prePersist() {
		fechaIngreso  = new Date();

	}
		
	@Column(name="tiene_historico")
	private boolean tieneHistorico;
	
	@Column(name="monto_previo")
	private float montoPrevio;
	
	@Column(name="concepto")
	private String concepto;
	
	
	@JoinColumn(name = "empleado_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_pago_empleado"))
	@ManyToOne (fetch = FetchType.EAGER) //no necesito modificar la columna de la entidad padre
	private Empleado empleado; //EAGER es el valor por defecto en este tipo de relaciones 
	
	

	@ManyToOne(fetch = FetchType.EAGER, cascade = CascadeType.REFRESH)
	@JoinColumn(nullable = true, name = "tipopago_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_pago_tipopago"))
	private TipoPago tipoPago ;

	
	//Un pago puede tener relacionado alguno de los siguientes objetos:
	//pago es como se va a identificar en las otras tablas 
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(nullable =  true, name = "pension_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_pago_pension"))
	private Pension montoPension ;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(nullable =  true, name = "seguro_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_pago_segurosocial"))
	private SeguroSocial seguroSocial;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(nullable =  true, name = "renta_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_pago_renta"))
	private Renta montoRenta;
	
	@OneToOne(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	@JoinColumn(nullable =  true, name = "bienestar_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_pago_bienestar"))
	private BienestarMagisterial bienestarMag;
	//PUede tener cada uno de estos o puede tener ninguno
	
	

	public Pago() {
		super();
	}
	
	
	
	public Pago(int id) {
		super();
		this.id = id;
	}



	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public float getMonto() {
		return monto;
	}
	public void setMonto(float monto) {
		this.monto = monto;
	}
	public String getMes() {
		return mes;
	}
	public void setMes(String mes) {
		this.mes = mes;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}

	public boolean isTieneHistorico() {
		return tieneHistorico;
	}
	public void setTieneHistorico(boolean tieneHistorico) {
		this.tieneHistorico = tieneHistorico;
	}
	public float getMontoPrevio() {
		return montoPrevio;
	}
	public void setMontoPrevio(float montoPrevio) {
		this.montoPrevio = montoPrevio;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
		
	public String getConcepto() {
		return concepto;
	}

	public void setConcepto(String concepto) {
		this.concepto = concepto;
	}


	public TipoPago getTipoPago() {
		return tipoPago;
	}




	public void setTipoPago(TipoPago tipoPago) {
		this.tipoPago = tipoPago;
	}


	public Pension getMontoPension() {
		return montoPension;
	}


	public void setMontoPension(Pension montoPension) {
		this.montoPension = montoPension;
	}


	public SeguroSocial getSeguroSocial() {
		return seguroSocial;
	}


	public void setSeguroSocial(SeguroSocial seguroSocial) {
		this.seguroSocial = seguroSocial;
	}


	public Renta getMontoRenta() {
		return montoRenta;
	}


	public void setMontoRenta(Renta montoRenta) {
		this.montoRenta = montoRenta;
	}


	public BienestarMagisterial getBienestarMag() {
		return bienestarMag;
	}


	public void setBienestarMag(BienestarMagisterial bienestarMag) {
		this.bienestarMag = bienestarMag;
	}






	@Override
	public String toString() {
		return "Renta [id=" + id + ", monto=" + monto + ", mes=" + mes + ", anio=" + anio + ", tieneHistorico="
				+ tieneHistorico + ", montoPrevio=" + montoPrevio;
	}


	

}
