package com.sga.domain;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "permisos_pago")
public class PermisoPago {

	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name = "codigo")
	private String codigo;
	
	@Column(name="nombre")
	private String nombre;

	@ManyToMany(mappedBy = "permisos", fetch = FetchType.EAGER)
	private List<TipoEmpleado> tipoPagos;
	
	

	public PermisoPago() {
		super();
	}

	public PermisoPago(int id) {
		super();
		this.id = id;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}
	
	public List<TipoEmpleado> getTipoPagos() {
		return tipoPagos;
	}

	public void setTipoPagos(List<TipoEmpleado> tipoPagos) {
		this.tipoPagos = tipoPagos;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
	
	
}
