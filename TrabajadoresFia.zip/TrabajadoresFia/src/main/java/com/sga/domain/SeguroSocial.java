package com.sga.domain;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "segurosocial")
public class SeguroSocial {
	
	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@Column(name="monto")
	private float monto=0.00F;
		
	@Column(name="tiene_historico")
	private boolean tieneHistorico;
	
	@Column(name="monto_previo")
	private float montoPrevio;
	
	
	@OneToOne(mappedBy = "seguroSocial", fetch = FetchType.LAZY)
	private Pago pago; //pago es como se le coloco que en la Clase Pago
	

	public SeguroSocial() {
		super();
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public float getMonto() {
		return monto;
	}

	public void setMonto(float monto) {
		this.monto = monto;
	}

	public boolean isTieneHistorico() {
		return tieneHistorico;
	}

	public void setTieneHistorico(boolean tieneHistorico) {
		this.tieneHistorico = tieneHistorico;
	}

	public float getMontoPrevio() {
		return montoPrevio;
	}

	public void setMontoPrevio(float montoPrevio) {
		this.montoPrevio = montoPrevio;
	}
	

	public Pago getPago() {
		return pago;
	}

	public void setPago(Pago pago) {
		this.pago = pago;
	}

	@Override
	public String toString() {
		return "SeguroVida [id=" + id + ", monto=" + monto + ", mes=" + 
	tieneHistorico + ", montoPrevio=" + montoPrevio + "]";
	}
	
	
	

}
