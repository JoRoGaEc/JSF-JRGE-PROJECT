package com.sga.domain;

import java.util.Calendar;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.ForeignKey;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.NamedQuery;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.OneToOne;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.Table;
import javax.validation.constraints.Null;
import javax.persistence.NamedStoredProcedureQuery;
import javax.persistence.StoredProcedureParameter;
import javax.persistence.ParameterMode;

@Entity
@Table(name="informe_excel")
@NamedStoredProcedureQuery(
        name="calcularTotalesDao",
        procedureName="calcularTotales",
        resultClasses = { InformeExcel.class },
        parameters={
            @StoredProcedureParameter(name="anio", type=Integer.class, mode=ParameterMode.IN),

        }
)
public class InformeExcel {


	@Id
	@Column(name="id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	

	@Column(name="monto_devengado", nullable = true)
	private Float montoDevengado = 0.00F;
	
	@Column(name="bonificaciones", nullable = true)
	private Float bonificaciones = 0.00F;
	
	@Column(name="renta_anual", nullable = true)
	private Float rentaAnual= 0.00F;
	
	@Column(name="aguinaldo_exento", nullable = true)
	private Float aguinaldoExento= 0.00F;
	
	@Column(name="aguinaldo_gravado", nullable = true)
	private Float aguinaldoGravado= 0.00F;
	
	@Column(name="seguro_anual", nullable = true)
	private Float seguroAnual= 0.00F;
	
	@Column(name="pension_anual", nullable = true)
	private Float pensionAnual= 0.00F;
	
	@Column(name="anio", nullable = true)
    private int anio= Calendar.YEAR;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(nullable =  true, name = "empleado_id", referencedColumnName = "id", foreignKey = @ForeignKey(name = "fk_informe_empleado"))
	private Empleado empleado ;	

	public float getMontoDevengado() {
		return montoDevengado;
	}

	public void setMontoDevengado(float montoDevengado) {
		this.montoDevengado = montoDevengado;
	}

	public float getBonificaciones() {
		return bonificaciones;
	}

	public void setBonificaciones(float bonificaciones) {
		this.bonificaciones = bonificaciones;
	}

	public float getRentaAnual() {
		return rentaAnual;
	}

	public void setRentaAnual(float rentaAnual) {
		this.rentaAnual = rentaAnual;
	}

	public float getAguinaldoExento() {
		return aguinaldoExento;
	}

	public void setAguinaldoExento(float aguinaldoExento) {
		this.aguinaldoExento = aguinaldoExento;
	}

	public float getAguinaldoGravado() {
		return aguinaldoGravado;
	}

	public void setAguinaldoGravado(float aguinaldoGravado) {
		this.aguinaldoGravado = aguinaldoGravado;
	}

	public float getSeguroAnual() {
		return seguroAnual;
	}

	public void setSeguroAnual(float seguroAnual) {
		this.seguroAnual = seguroAnual;
	}

	public float getPensionAnual() {
		return pensionAnual;
	}

	public void setPensionAnual(float pensionAnual) {
		this.pensionAnual = pensionAnual;
	}

	public int getAnio() {
		return anio;
	}

	public void setAnio(int anio) {
		this.anio = anio;
	}
	
	
	
	
	
	
}
