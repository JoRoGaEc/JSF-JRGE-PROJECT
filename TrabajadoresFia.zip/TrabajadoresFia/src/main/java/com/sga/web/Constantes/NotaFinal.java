package com.sga.web.Constantes;

public class NotaFinal {

	public static String  NOTA_MENSAJE= "Y PARA LOS EFECTOS DE SU DECLARACIÓN DE IMPUESTO SOBRE LA RENTA , SE EXTIENDE A LOS ";
	
}
