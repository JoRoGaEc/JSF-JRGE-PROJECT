package com.sga.web.Reports;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import com.sga.domain.Empleado;
import com.sga.services.ReportesService;

@Named("reporteBean")
@RequestScoped
public class ReporteBean {

	Logger LOG = (Logger) LogManager.getRootLogger();
	@Inject
	private ReportesService reporteService;
	private List<Empleado>  empleados;
	
	@PostConstruct
	public void inicializar() {
		empleados =  reporteService.empleadosByYear(2020);
	}

	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}
	
	
	
	
}
