package com.sga.web;

import java.io.IOException;
import java.io.Serializable;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.ExternalContext;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.http.HttpSession;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.primefaces.PrimeFaces;

import com.sga.datos.TipoPagoDao;
import com.sga.domain.BienestarMagisterial;
import com.sga.domain.Empleado;
import com.sga.domain.Pago;
import com.sga.domain.Pension;
import com.sga.domain.PermisoPago;
import com.sga.domain.Renta;
import com.sga.domain.SeguroSocial;
import com.sga.domain.TipoEmpleado;
import com.sga.domain.TipoPago;
import com.sga.services.EmpleadoService;
import com.sga.services.PagosService;
import com.sga.services.TipoEmpleadoService;
import com.sga.services.TipoPagoService;
import com.sga.web.security.*;;

@Named("pagoBean")
@RequestScoped
public class PagoBean implements Serializable {

	private static final long serialVersionUID = 1094801825228386363L;

	Logger LOG = (Logger) LogManager.getRootLogger();

	private Empleado empleadoSeleccionado;
	private int idEmpSel;
	private Pago pago;
	private String mesPago;
	private String primerIngreso;
	private Map<String, String> permisos;

	@Inject
	private PagosService pagosService;

	@Inject
	private EmpleadoService empleadoService;

	private List<Empleado> empleados;
	
	@Inject
	private TipoEmpleadoService tipoEmpleadoService;
	
	@Inject
	private MenuBean menuBean;

	HttpSession session;

	@PostConstruct
	public void inicializar() {
		String script = null;
		ExternalContext eContext =  (ExternalContext) FacesContext.getCurrentInstance().getExternalContext();
		LOG.debug("METHOD : " + "inicializar()");
		empleados = empleadoService.listaEmpleados();
		permisos  = new HashMap<String, String>();
		session = SessionUtils.getSession();
		if (((String) session.getAttribute("mesPago")) == null) {
			mesPago = "Enero";
			session.setAttribute("mesPago", mesPago);
		} else {
			mesPago = ((String) session.getAttribute("mesPago"));
			LOG.debug("MES SELECCIOADO " + mesPago);
		}
		if (empleados.size() > 0) {
			LOG.debug("IDEmpleadoActualEnSesion "  + (Integer) session.getAttribute("idEmpleadoActual"));
			if ((Integer) session.getAttribute("idEmpleadoActual") == null) {
				empleadoSeleccionado = empleados.get(0);
				session.setAttribute("idEmpleadoActual", empleadoSeleccionado.getId());
			}else {
				int idEmp  =  (int) session.getAttribute("idEmpleadoActual");
				for(Empleado e:  empleados) {
					if(e.getId() == idEmp) {
						empleadoSeleccionado = e;
					}
				}
			}
			script = "document.getElementById('_idPagoEmp2').style.display = 'block'" + ";";
			PrimeFaces.current().executeScript(script);
		}
		pago = new Pago();
		pago.setMontoRenta(new Renta());
		pago.setBienestarMag(new BienestarMagisterial());
		pago.setMontoPension(new Pension());
		pago.setSeguroSocial(new SeguroSocial());
		
		
		llamarPermisos(empleadoSeleccionado.getId());

		LOG.debug("FIN METHOD : " + "inicializar()");
	}
/*	public void sinEmpleados() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
			String contextPath = FacesContext.getCurrentInstance().getExternalContext().getRequestContextPath();
	        try {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO", "No hay ningún trabajador"));
				FacesContext.getCurrentInstance().getExternalContext().redirect(contextPath + "/empleados/listaEmpleados.xhtml");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		    FacesContext.getCurrentInstance().responseComplete();
		}

	}*/
	
	
	private void llamarPermisos(int id) {
		Empleado e =  empleadoService.find(id);
		TipoEmpleado te  = tipoEmpleadoService.buscarTipoEmpleadoById(new TipoEmpleado(e.getTipoEmpleado().getId()));
		for(PermisoPago p : te.getPermisos()) { //aca asigno los permisos al HashMap
			permisos.put(p.getCodigo(), p.getCodigo());
		}
	}

	public Empleado getEmpleadoSeleccionado() {
		return empleadoSeleccionado;
	}

	public void setEmpleadoSeleccionado(Empleado empleadoSeleccionado) {
		this.empleadoSeleccionado = empleadoSeleccionado;
	}

	public void onEmpleadoChange() {
		LOG.debug("METHOD: " + " onEmpleadoChange() ");

		FacesContext context = FacesContext.getCurrentInstance();
		idEmpSel = empleadoSeleccionado.getId();
		LOG.debug("EVENTO CHANGE: " + idEmpSel);
		context.getExternalContext().getSessionMap().put("idEmpleadoActual", idEmpSel);

		String script = null;
		if (idEmpSel != 0) {
			LOG.debug("METHOD: " + " onEmpleadoChange() -- IF-Case");
			script = "document.getElementById('_idPagoEmp2').style.display = 'block' " + ";";
			PrimeFaces.current().executeScript(script);

		} else {
			LOG.debug("METHOD: " + " onEmpleadoChange() -- ELSE-Case");
			script = "document.getElementById('_idPagoEmp2').style.display = 'none'" + ";";
			PrimeFaces.current().executeScript(script);
			context = FacesContext.getCurrentInstance();
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO", "Debe seleccionar un trabajador"));

		}
		
	

	}

	public String realizarPago() {
		int year = Calendar.getInstance().get(Calendar.YEAR);
		LOG.debug("METHOD: " + " realizarPago() ");
		FacesContext context = FacesContext.getCurrentInstance();
		mesPago = (String) context.getExternalContext().getSessionMap().get("mesPago");
		LOG.debug("Mes PAGO",mesPago);
		int empb = (int) context.getExternalContext().getSessionMap().get("idEmpleadoActual");
		LOG.debug("ID EMPLEADO sesion"  + empb);

		Empleado emp = empleadoService.encontrarEmpleadoPorId(new Empleado(empb));
		System.out.println("El empleado recuperado es" + emp.getNombre());
		pago.setAnio(year);
		pago.setTipoPago(new TipoPago(1));
		pago.setEmpleado(emp);
		pago.setMes(mesPago);
		// lo demas ya lo tiene guardado
		pagosService.guardarPago(pago); // AQUI SE PERSISTE EL PAGO Y SE REALIZA EN CASCADA
		LOG.debug("METHOD: " + " /empleados/listaEmpleados ");
		resetearValores();
		String script = null;
		script = "document.getElementById('_idPagoEmp2').style.display = 'block'" + ";";
		PrimeFaces.current().executeScript(script);
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_INFO, "AVISO", "Guardado con éxito"));

		return "/pagos/pagoNormal" + "?faces-redirect  = true";
	}

	public int getIdEmpSel() {
		return idEmpSel;
	}

	public void setIdEmpSel(int idEmpSel) {
		this.idEmpSel = idEmpSel;
	}

//Para el Pago
	public Pago getPago() {
		return pago;
	}

	public void setPago(Pago pago) {
		this.pago = pago;
	}

	public List<Empleado> getEmpleados() {
		return empleados;
	}

	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}

	public String getMesPago() {
		return mesPago;
	}

	public void setMesPago(String mesPago) {
		this.mesPago = mesPago;
	}

//esto por los cambios del mes
	public void onChangeMes() {
		LOG.debug("METHOD : " + "onChangeMes()");
		FacesContext context = FacesContext.getCurrentInstance();
		context.getExternalContext().getSessionMap().put("mesPago", this.mesPago);
		LOG.debug("MES PAGO"  +  this.mesPago);

	}

	private void resetearValores() {
		pago = new Pago();
		pago.setMontoRenta(new Renta());
		pago.setBienestarMag(new BienestarMagisterial());
		pago.setMontoPension(new Pension());
		pago.setSeguroSocial(new SeguroSocial());
	}

	public String getPrimerIngreso() {
		return primerIngreso;
	}

	public void setPrimerIngreso(String primerIngreso) {
		this.primerIngreso = primerIngreso;
	}

	public Map<String, String> getPermisos() {
		return permisos;
	}

	public void setPermisos(Map<String, String> permisos) {
		this.permisos = permisos;
	}

	public PagosService getPagosService() {
		return pagosService;
	}

	public void setPagosService(PagosService pagosService) {
		this.pagosService = pagosService;
	}

	public EmpleadoService getEmpleadoService() {
		return empleadoService;
	}

	public void setEmpleadoService(EmpleadoService empleadoService) {
		this.empleadoService = empleadoService;
	}

	public TipoEmpleadoService getTipoEmpleadoService() {
		return tipoEmpleadoService;
	}

	public void setTipoEmpleadoService(TipoEmpleadoService tipoEmpleadoService) {
		this.tipoEmpleadoService = tipoEmpleadoService;
	}


	

}
