package com.sga.web.Reports;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.inject.Inject;
import javax.inject.Named;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import com.sga.domain.Empleado;
import com.sga.services.ReportesService;
import com.sga.web.NotaBean;

import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JREmptyDataSource;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

@Named("reporteExcelBean")
@RequestScoped
public class ReporteExcelBean {

	private String invoiceName;
	private JRBeanCollectionDataSource beanCollectionDataSource;
	private Map<String, Object> parametros;
	private Empleado empleadoBoleta;
	private HttpServletResponse response;
	private String value;
	private Empleado empleado ;
	private int idEmpleado;

	@Inject
	private ReportesService reporteService;
	@Inject
	private NotaBean notaBean;
	
	public Empleado generarBoletaEmpleado() {
		return reporteService.empleadoParaBoleta(1);
	}

	public void exportarPDF(ActionEvent event) throws JRException, IOException {
		parametros = new HashMap<String, Object>();
	    int idEmpSel  = (int)event.getComponent().getAttributes().get("idEmpleadoPas");//idEmpleadoPas es el name del f param
	    System.out.println("PARAMETRO" + idEmpSel);   
		empleado =  reporteService.empleadoParaBoleta(idEmpSel);
		
		parametros.put("txtNit",empleado.getNit());
        parametros.put("logo-ues", FacesContext.getCurrentInstance().getExternalContext().getRealPath("/jasper/logo-ues.jpg"));
		//MONTOS GRAVADOS	
		parametros.put("txtNombreCompleto", empleado.getApellido().toUpperCase() +  " " + empleado.getNombre().toUpperCase());
		parametros.put("txtSueldo",  "$ " + empleado.getInforme().getMontoDevengado());
		parametros.put("txtBonos", "$ " + empleado.getInforme().getBonificaciones());
		parametros.put("txtAguinaldo","$ " + empleado.getInforme().getAguinaldoGravado());
		float suma  = empleado.getInforme().getMontoDevengado() + empleado.getInforme().getBonificaciones()
					 + empleado.getInforme().getAguinaldoGravado();					
		parametros.put("txtTotalGrav", "$ " + String.valueOf(suma));
		//INGRESOS NO GRAVADOS
		if(empleado.getTipoPension().getCodigo().equals("AFP")) {
			System.out.println("Ingrese al if de afp");
			parametros.put("txtAfp", "$ " + empleado.getInforme().getPensionAnual());
			parametros.put("txtInpep", "$ 0.00");
			parametros.put("txtIpsfa", "$ 0.00");
			parametros.put("txtCefafa", "$ 0.00");
			parametros.put("txtBm", "$ 0.00");
		}
		if(empleado.getTipoPension().getCodigo().equals("INPEP")) {
			System.out.println("if del inpep");
			parametros.put("txtInpep", "$ " + empleado.getInforme().getPensionAnual());
			parametros.put("txtAfp", "$ 0.00");
			parametros.put("txtIpsfa", "$ 0.00");
			parametros.put("txtCefafa", "$ 0.00");
			parametros.put("txtBm", "$ 0.00");
		}
		
		if(empleado.getTipoPension().getCodigo().equals("IPSFA")) {
			parametros.put("txtIpsfa","$ " + empleado.getInforme().getPensionAnual());
			parametros.put("txtAfp", "$ 0.00");
			parametros.put("txtInpep", "$ 0.00");
			parametros.put("txtCefafa", "$ 0.00");
			parametros.put("txtBm", "$ 0.00");
		}
		if(empleado.getTipoPension().getCodigo().equals("CEFAFA")) {
			parametros.put("txtCefafa", "$ " + empleado.getInforme().getPensionAnual());
			parametros.put("txtIpsfa", "$ 0.00");
			parametros.put("txtAfp", "$ 0.00");
			parametros.put("txtInpep", "$ 0.00");
			parametros.put("txtBm", "$ 0.00");
		}
		if(empleado.getTipoPension().getCodigo().equals("BM")) {
			parametros.put("txtBm",  "$ " + empleado.getInforme().getPensionAnual());
			parametros.put("txtCefafa","$ 0.00");
			parametros.put("txtIpsfa", "$ 0.00");
			parametros.put("txtAfp", "$ 0.00");
			parametros.put("txtInpep", "$ 0.00");
			
		}
		parametros.put("txtIsss", "$ " + empleado.getInforme().getSeguroAnual());
		parametros.put("txtAguinaldoEx",  "$ " + empleado.getInforme().getAguinaldoExento());
		
		suma =  empleado.getInforme().getPensionAnual() + empleado.getInforme().getSeguroAnual() + empleado.getInforme().getAguinaldoExento();
		
		parametros.put("txtTotalNoGrav","$ "+ String.valueOf(suma));
		parametros.put("txtIsr", "$ " + empleado.getInforme().getRentaAnual());
		parametros.put("txtNota", notaBean.getNotaCompleta().toUpperCase());
		
		File jasper = new File(FacesContext.getCurrentInstance().getExternalContext().getRealPath("/jasper/boletaEmpleado.jasper"));
		JRDataSource datasource = new JREmptyDataSource();
		JasperPrint jasperPrint = JasperFillManager.fillReport(jasper.getPath(), parametros, datasource);
		HttpServletResponse response = (HttpServletResponse) FacesContext.getCurrentInstance().getExternalContext()
				.getResponse();
		response.addHeader("Content-disposition", "attachment; filename ="+ empleado.getNit() + ".pdf");
		ServletOutputStream stream = response.getOutputStream();

		JasperExportManager.exportReportToPdfStream(jasperPrint, stream); // jasperPrint es el jasper llenado

		stream.flush();
		stream.close();
		FacesContext.getCurrentInstance().responseComplete();
	}

	public String getInvoiceName() {
		return invoiceName;
	}

	public void setInvoiceName(String invoiceName) {
		this.invoiceName = invoiceName;
	}

	public JRBeanCollectionDataSource getBeanCollectionDataSource() {
		return beanCollectionDataSource;
	}

	public void setBeanCollectionDataSource(JRBeanCollectionDataSource beanCollectionDataSource) {
		this.beanCollectionDataSource = beanCollectionDataSource;
	}

	public Map<String, Object> getParametros() {
		return parametros;
	}

	public void setParametros(Map<String, Object> parametros) {
		this.parametros = parametros;
	}

	public ReportesService getReporteService() {
		return reporteService;
	}

	public void setReporteService(ReportesService reporteService) {
		this.reporteService = reporteService;
	}

	public Empleado getEmpleadoBoleta() {
		return empleadoBoleta;
	}

	public void setEmpleadoBoleta(Empleado empleadoBoleta) {
		this.empleadoBoleta = empleadoBoleta;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Empleado getEmpleado() {
		return empleado;
	}

	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}

	public int getIdEmpleado() {
		return idEmpleado;
	}

	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}






















}




