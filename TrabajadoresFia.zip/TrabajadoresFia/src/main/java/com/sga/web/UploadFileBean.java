package com.sga.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.primefaces.event.FileUploadEvent;
import org.primefaces.model.UploadedFile;
import com.sga.services.ReadFileService;

@Named("uploadFileBean")
@RequestScoped
public class UploadFileBean implements Serializable{
	static Logger LOG = LogManager.getLogger();
	
	@Inject 
	private ReadFileService rfs;
	
	private static final long serialVersionUID = 1L;	
	private UploadedFile file;

	
	public void upload() {
		int result=0;
		try {
			InputStream is =  file.getInputstream();
			//LOG.debug("GETNAME " + file.getFileName(is));
			result  = rfs.readExcelFile(is);
			if(result == 1) {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "OK", "Datos cargados exitosamente"));
			}else if(result == 3) {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR", "Tipo de empleado no existente, usado en el excel"));
			}else if(result ==4) {
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "ERROR", "Tipo de pensión no existente, usada en el excel "));				
			}
			
		} catch (IOException e) {
			if(result==0) {
			
				FacesContext.getCurrentInstance().addMessage(null,
						new FacesMessage(FacesMessage.SEVERITY_INFO, "BAD", "Error en la carga"));				
			}
			e.printStackTrace();
		}	
	}
		
	public UploadedFile getFile() {
		return file;
	}

	public void setFile(UploadedFile file) {
		this.file = file;
	}
	
}
