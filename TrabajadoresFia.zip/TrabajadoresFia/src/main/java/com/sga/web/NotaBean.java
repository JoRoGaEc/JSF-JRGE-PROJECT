package com.sga.web;

import static com.sga.web.Constantes.NotaFinal.NOTA_MENSAJE;

import java.io.Serializable;

import javax.enterprise.context.SessionScoped;
import javax.faces.event.ActionEvent;
import javax.inject.Named;

@Named("notaBean")
@SessionScoped
public class NotaBean implements Serializable{
	private static final long serialVersionUID = 1L;
	private String notaParte2 ;
	private String notaCompleta;

	public String getNotaParte2() {
		return notaParte2;
	}

	public void setNotaParte2(String notaParte2) {
		this.notaParte2 = notaParte2;
	}
	
	public void guardar(ActionEvent event) {
		notaCompleta = NOTA_MENSAJE + " " +notaParte2;
	}

	public String getNotaCompleta() {
		return notaCompleta;
	}

	public void setNotaCompleta(String notaCompleta) {
		this.notaCompleta = notaCompleta;
	}
	
	
	
}
