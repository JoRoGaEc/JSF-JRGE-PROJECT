package com.sga.web;

import java.io.IOException;
import java.util.List;

import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.validator.ValidatorException;
import javax.inject.Inject;
import javax.inject.Named;

import com.sga.domain.Empleado;
import com.sga.services.EmpleadoService;

@Named("menuBean")
@RequestScoped
public class MenuBean {

	private List<Empleado> empleados;
	public static final String LISTA_EMPLEADOS = "/empleados/listaEmpleados.xhtml";
	
	
	@Inject 
	private EmpleadoService empleadoService;
	
	
	public String listadoEmpleados() {
		return "/empleados/listaEmpleados" + "?faces-redirect=true";
	}
	
	
	public String pagoNormal() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Debe agregar al menos un empleado"));
			//return "/empleados/listaEmpleados.xhtml";
		}else {
			return "/pagos/pagoNormal"+ "?faces-redirect=true";
		}

	}
	
	
	public String listaTipoEmpleados() {
		return "/tipoempleados/listaTipoEmpleados"+ "?faces-redirect=true";
	}
	
	public String listaTipoPensiones() {
		return "/tipopensiones/listaTipoPensiones"+ "?faces-redirect=true";
	}
	
	public String bonificacion() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Debe agregar al menos un empleado"));
			//return "/empleados/listaEmpleados.xhtml";
		}else {
			return "/pagos/pagoBono"+ "?faces-redirect=true";
		}		

	}
	
	public String pagoAguinaldoExento() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Debe agregar al menos un empleado"));
			//return "/empleados/listaEmpleados.xhtml";
		}else {
			return "/pagos/pagoAguinaldo"+ "?faces-redirect=true";
		}		
	}
	
	public String pagoAguinaldoGravado() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Debe agregar al menos un empleado"));
			//return "/empleados/listaEmpleados.xhtml";
		}else {
			return "/pagos/pagoAguinaldoGravado"+ "?faces-redirect=true";
		}
		
	}	
	public String pagoEspecial() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Debe agregar al menos un empleado"));
			//return "/empleados/listaEmpleados.xhtml";
		}else {
			return "/pagos/pagoEspecial"+ "?faces-redirect=true";
		}
	}

	
	public String reporteCsv() {
		empleados = empleadoService.listaEmpleados();
		if(empleados.size()<=0) {
            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Debe agregar al menos un empleado"));
			//return "/empleados/listaEmpleados.xhtml";
		}else {
			return "/reportes/reporteCsv" + "?faces-redirect=true";
		}
	}

	
	
	public String asignarTipoDePago() {
		return  "/administracion/asignarTipoDePago";
	}
	
	

}
