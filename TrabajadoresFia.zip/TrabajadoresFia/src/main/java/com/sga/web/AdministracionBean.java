package com.sga.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import com.sga.domain.PermisoPago;
import com.sga.domain.TipoEmpleado;
import com.sga.services.PermisoTipoService;
import com.sga.services.TipoEmpleadoService;

@Named("administracionBean")
@RequestScoped
public class AdministracionBean {

	@Inject
	private TipoEmpleadoService tipoEmpleadoService;
	
	@Inject 
	private PermisoTipoService permisoTipoService;
	
	private TipoEmpleado tipoEmpleadoSeleccionado;
	private List<TipoEmpleado> tipoEmpleados;
	private Map<String, String> permisos;
	
	//Opciones de renderizacion
    private boolean monto;
    private boolean aguinaldoExento;
    private boolean aguinaldoGravado;
    private boolean afp;
    private boolean isr;
    private boolean isss;
    private boolean inpep;
    private boolean ipsfa;
    private boolean bienestarMagisterial;
    private boolean cefafa;
    private boolean bonos;
    
    Logger LOG = (Logger) LogManager.getRootLogger();
	
	@PostConstruct
	public void inicializar() {
		LOG.debug("METHOD: " + "inicializar()");
		tipoEmpleados  = tipoEmpleadoService.listarTipoEmpleados();
		tipoEmpleadoSeleccionado = new TipoEmpleado();
		 
		LOG.debug("FIN METHOD: " + "inicializar()");
	}
	//metodo para actualizar
	public void actualizarTipo() {
		permisos = new HashMap<String, String>();
		LOG.debug("METHOD: " + "actualizarTipo()");
		LOG.debug("TipoEmpleado: " + tipoEmpleadoSeleccionado);
		TipoEmpleado tipoEmp =  new TipoEmpleado();
		if(tipoEmpleadoSeleccionado == null) {
			
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO", "Debe seleccionar algun tipo"));
		}else {
			tipoEmp = tipoEmpleadoService.buscarTipoEmpleadoById(new TipoEmpleado(tipoEmpleadoSeleccionado.getId()));
			inicializarTipos();
			   LOG.debug("VOY A ITERAR LOS PERMISOS: " + "...");
				for(PermisoPago pp : tipoEmp.getPermisos()) {
					LOG.debug("ITERANDO LOS PERMISOS : "  + pp);
					permisos.put(pp.getCodigo(), pp.getNombre());
				}
				marcarPermisos();
					
			
			
		}		
		LOG.debug("FIN METHOD: " + "actualizarTipo()");
	}
	
	private void marcarPermisos() {
		if (permisos.containsKey("MONTO")) {
			LOG.debug("PERMISO CAMBIADO A TRUE" );
			monto = true;
		}
		if(permisos.containsKey("AGUINALDO_GRAVADO")) {
			aguinaldoGravado =  true;
		}
		if(permisos.containsKey("AGUINALDO_EXENTO")) {
			this.aguinaldoExento =  true;
		}
		if(permisos.containsKey("AFP")) {
			this.afp =  true;
		}
		if(permisos.containsKey("ISR")) {
			this.isr =  true;
		}		
		if(permisos.containsKey("ISSS")) {
			this.isss =  true;
		}
		if(permisos.containsKey("INPEP")) {
			this.inpep =  true;
		}
		if(permisos.containsKey("IPSFA")) {
			this.ipsfa =  true;
		}
		if(permisos.containsKey("BM")) {
			this.bienestarMagisterial =  true;
		} 
		if(permisos.containsKey("CEFAFA")) {
			this.cefafa =  true;
		} 
		if(permisos.containsKey("BONOS")) {
			this.bonos =  true;
		} 
	}
	private void inicializarTipos() {		
	    monto = false;
	    aguinaldoExento =  false;
	    aguinaldoGravado= false;
	    afp = false;
	    isr= false;
	    isss=false;
	    inpep=false;
	    ipsfa= false;
	    bienestarMagisterial= false;
	    cefafa=  false;
	    bonos = false;
	}
	
	public void guardarCambios() {
		TipoEmpleado tipoEmp =  new TipoEmpleado();
		List<PermisoPago> permisosNuevos  =  new ArrayList<PermisoPago>();
		if(tipoEmpleadoSeleccionado == null) {
			
			FacesContext.getCurrentInstance().addMessage(null,
					new FacesMessage(FacesMessage.SEVERITY_WARN, "AVISO", "Debe seleccionar algun tipo"));
		}else {
			tipoEmp = tipoEmpleadoService.buscarTipoEmpleadoById(new TipoEmpleado(tipoEmpleadoSeleccionado.getId()));
					if (this.monto == true) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(1));
					}
					if((this.aguinaldoGravado == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(2));
					}
					if((this.aguinaldoExento == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(3));
					}
					if((this.afp == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(4));
					}
					if((this.isr == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(5));
					}
					if((this.isss== true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(6));
					}
					if((this.inpep == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(7));
					}
					if((this.ipsfa == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(8));
					}
					if((this.bienestarMagisterial == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(9));
					}
					if((this.cefafa == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(10));
					}
					if((this.bonos == true)) {
						permisosNuevos.add(permisoTipoService.buscarPermisoById(11));
					}
					tipoEmp.setPermisos(permisosNuevos);
					tipoEmpleadoService.actualizarEmpleado(tipoEmp);
					inicializarTipos();
					actualizarTipo();
					FacesContext.getCurrentInstance().addMessage(null,
							new FacesMessage(FacesMessage.SEVERITY_INFO, "AVISO", "Se ha actualizado con éxito"));

					
		}
	}
	
	

	public TipoEmpleadoService getTipoEmpleadoService() {
		return tipoEmpleadoService;
	}

	public void setTipoEmpleadoService(TipoEmpleadoService tipoEmpleadoService) {
		this.tipoEmpleadoService = tipoEmpleadoService;
	}

	public TipoEmpleado getTipoEmpleadoSeleccionado() {
		return tipoEmpleadoSeleccionado;
	}

	public void setTipoEmpleadoSeleccionado(TipoEmpleado tipoEmpleadoSeleccionado) {
		this.tipoEmpleadoSeleccionado = tipoEmpleadoSeleccionado;
	}

	public List<TipoEmpleado> getTipoEmpleados() {
		return tipoEmpleados;
	}

	public void setTipoEmpleados(List<TipoEmpleado> tipoEmpleados) {
		this.tipoEmpleados = tipoEmpleados;
	}

	public boolean isMonto() {
		return monto;
	}

	public void setMonto(boolean monto) {
		this.monto = monto;
	}

	public boolean isAguinaldoExento() {
		return aguinaldoExento;
	}

	public void setAguinaldoExento(boolean aguinaldoExento) {
		this.aguinaldoExento = aguinaldoExento;
	}

	public boolean isAguinaldoGravado() {
		return aguinaldoGravado;
	}

	public void setAguinaldoGravado(boolean aguinaldoGravado) {
		this.aguinaldoGravado = aguinaldoGravado;
	}

	public boolean isAfp() {
		return afp;
	}

	public void setAfp(boolean afp) {
		this.afp = afp;
	}

	public boolean isIsr() {
		return isr;
	}

	public void setIsr(boolean isr) {
		this.isr = isr;
	}

	public boolean isIsss() {
		return isss;
	}

	public void setIsss(boolean isss) {
		this.isss = isss;
	}

	public boolean isInpep() {
		return inpep;
	}

	public void setInpep(boolean inpep) {
		this.inpep = inpep;
	}

	public boolean isIpsfa() {
		return ipsfa;
	}

	public void setIpsfa(boolean ipsfa) {
		this.ipsfa = ipsfa;
	}

	public boolean isBienestarMagisterial() {
		return bienestarMagisterial;
	}

	public void setBienestarMagisterial(boolean bienestarMagisterial) {
		this.bienestarMagisterial = bienestarMagisterial;
	}

	public boolean isCefafa() {
		return cefafa;
	}

	public void setCefafa(boolean cefafa) {
		this.cefafa = cefafa;
	}

	public boolean isBonos() {
		return bonos;
	}

	public void setBonos(boolean bonos) {
		this.bonos = bonos;
	}
	public Map<String, String> getPermisos() {
		return permisos;
	}
	public void setPermisos(Map<String, String> permisos) {
		this.permisos = permisos;
	}
	public PermisoTipoService getPermisoTipoService() {
		return permisoTipoService;
	}
	public void setPermisoTipoService(PermisoTipoService permisoTipoService) {
		this.permisoTipoService = permisoTipoService;
	}
	
	

	
}
