package com.sga.web.editarPagos;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;
import javax.enterprise.context.RequestScoped;
import javax.enterprise.context.SessionScoped;
import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;
import javax.faces.event.ActionEvent;
import javax.faces.event.ComponentSystemEvent;
import javax.inject.Inject;
import javax.inject.Named;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;

import com.sga.domain.Empleado;
import com.sga.domain.Pago;
import com.sga.services.EmpleadoService;
import com.sga.services.PagosService;
import com.sga.services.ReportesService;

@Named("editarPagos")
@SessionScoped
public class EditarPagos implements Serializable{

	private static final long serialVersionUID = 1L;
	@Inject
	private ReportesService reporteService;
	@Inject 
	private EmpleadoService empleadoService;
	
	@Inject
	private PagosService pagoService;
	
	
	private Empleado empleado;
	private int name;
	private int periodo ;
	private String mes;
	private int idEmpleado;
	private int tipoPago;
	private int anio;
	private List<Pago> pagos;
	private Map<String, String> periodos=  new HashMap<String, String>();	
	Logger LOG = (Logger) LogManager.getRootLogger();
	
	@PostConstruct
	public void inicializar() {
		LOG.debug("METHOD : " + "inicializar()");
		
		
		LOG.debug("FIN METHOD : " + "inicializar()");
	}
	
	
    public void before(ComponentSystemEvent event){
        if (!FacesContext.getCurrentInstance().isPostback()){
            System.out.println("PreRenderView: view parameters are available here");
            System.out.println("Name: " + name);
            idEmpleado  = (int)name;
            empleado = empleadoService.find(idEmpleado);
        }
       
    }
	
	//Para buscar los pagos de los empleados
	public void buscarPagos(ActionEvent event) {
		LOG.debug("METHOD : " + "buscarPagos()");
		pagos = pagoService.pagosPorEmpleado(idEmpleado, mes, anio, tipoPago);
		LOG.debug("FIN METHOD : " + "buscarPagos()");
	}
	
	public void delete(ActionEvent event){
		LOG.debug("METHOD : " + "delete()");
	    int idEmpSel  = (int)event.getComponent().getAttributes().get("idEmple");//idEmpleadoPas es el name del f param
	    System.out.println("PARAMETRO" + idEmpSel);
		pagoService.eliminarPago(idEmpSel);
		//Pago pago =  new Pago(idEmpSel);
		//pagos.remove(pago);
		actualizarTabla(this.idEmpleado, this.mes, this.anio, this.tipoPago);		
		FacesContext.getCurrentInstance().addMessage(null,
				new FacesMessage(FacesMessage.SEVERITY_WARN, "Eliminado", "Pago eliminado con éxito"));
	 }
	
	public void actualizarTabla(int id, String mes, int anio, int tipoPago) {
		pagos = pagoService.pagosPorEmpleado(id, mes, anio, tipoPago);
	}
	
	public ReportesService getReporteService() {
		return reporteService;
	}
	public void setReporteService(ReportesService reporteService) {
		this.reporteService = reporteService;
	}

	public int getName() {
		return name;
	}
	public void setName(int name) {
		this.name = name;
	}


	public Map<String, String> getPeriodos() {
		return periodos;
	}


	public void setPeriodos(Map<String, String> periodos) {
		this.periodos = periodos;
	}


	public Empleado getEmpleado() {
		return empleado;
	}


	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}


	public int getPeriodo() {
		return periodo;
	}


	public void setPeriodo(int periodo) {
		this.periodo = periodo;
	}


	public String getMes() {
		return mes;
	}


	public void setMes(String mes) {
		this.mes = mes;
	}


	public int getIdEmpleado() {
		return idEmpleado;
	}


	public void setIdEmpleado(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}


	public int getTipoPago() {
		return tipoPago;
	}


	public void setTipoPago(int tipoPago) {
		this.tipoPago = tipoPago;
	}

	public int getAnio() {
		return anio;
	}


	public void setAnio(int anio) {
		this.anio = anio;
	}
	
	public List<Pago> getPagos() {
		return pagos;
	}

	public void setPagos(List<Pago> pagos) {
		this.pagos = pagos;
	}
		  
	  
}
