package com.sga.web.FacesValidator;

import javax.faces.application.FacesMessage;
import javax.faces.component.UIComponent;
import javax.faces.context.FacesContext;
import javax.faces.validator.FacesValidator;
import javax.faces.validator.Validator;
import javax.faces.validator.ValidatorException;

@FacesValidator("valorMinimoValidator")
public class ValidaEntero implements Validator {

    @Override
    public void validate(FacesContext context, UIComponent component, Object value) throws ValidatorException {
        float campoAValidar =  (Float)value;
        

	        if (campoAValidar <=0.0000) {
	            throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Valor del campo debe ser mayor que cero"));
	        }

    }

}