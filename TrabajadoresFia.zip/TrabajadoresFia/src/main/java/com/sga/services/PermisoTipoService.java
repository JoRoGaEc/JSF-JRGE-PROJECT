package com.sga.services;

import com.sga.domain.PermisoPago;

public interface PermisoTipoService {
	
	public abstract PermisoPago  buscarPermisoById(int id);
}
