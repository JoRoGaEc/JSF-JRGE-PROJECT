package com.sga.services;

import java.io.InputStream;

public interface ReadFileService {

	
	public abstract int readExcelFile(InputStream fis);
}
