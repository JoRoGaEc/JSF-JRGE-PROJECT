package com.sga.services.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.ReportesDao;
import com.sga.domain.Empleado;
import com.sga.services.ReportesService;

@Stateless
public class ReportesServiceImpl implements ReportesService{
	
	
	@Inject
	private ReportesDao reportesDao;


	@Override
	public List<Empleado> empleadosByYear(int anio) {	
		return reportesDao.calcularTotalesDao(anio);
	}

	@Override
	public Empleado empleadoParaBoleta(int id) {
		return reportesDao.empleadoParaBoleta(id);
	}
}
