package com.sga.services.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.TipoPagoDao;
import com.sga.domain.TipoPago;
import com.sga.services.TipoPagoService;

@Stateless
public class TipoPagoServiceImpl implements TipoPagoService{

	@Inject
	private TipoPagoDao tipoPagoDao;
	
	@Override
	public TipoPago recuperarTipoPago(int id) {		
		return tipoPagoDao.buscarTipoPago(id);
	}

}
