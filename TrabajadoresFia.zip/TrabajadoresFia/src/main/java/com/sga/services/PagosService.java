package com.sga.services;

import java.util.List;

import com.sga.domain.Pago;

public interface PagosService {

	public abstract void guardarPago(Pago pago);
	
	public abstract List<Pago> pagosPorEmpleado(int id, String mes , int anio , int tipoPago);
	
	public abstract void eliminarPago(int id);
}
