package com.sga.services.Impl;

import java.util.List;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.PagosDao;
import com.sga.domain.Pago;
import com.sga.services.PagosService;

@Stateless
public class PagosServiceImpl implements PagosService{

	@Inject
	private PagosDao pagosDao;
	
	@Override
	public void guardarPago(Pago pago) {
		pagosDao.save(pago);
	}

	@Override
	public List<Pago> pagosPorEmpleado(int id, String mes, int anio, int tipoPago) {
		return pagosDao.pagosPorEmpleado(id, mes, anio, tipoPago);
	}

	@Override
	public void eliminarPago(int id) {
		pagosDao.eliminarPago(id);
		
	}

}
