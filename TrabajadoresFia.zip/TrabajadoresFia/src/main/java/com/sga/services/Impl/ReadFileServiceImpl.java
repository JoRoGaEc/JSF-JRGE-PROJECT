package com.sga.services.Impl;

import java.io.IOException;
import java.io.InputStream;

import javax.ejb.Stateless;
import javax.faces.application.FacesMessage;
import javax.faces.validator.ValidatorException;
import javax.inject.Inject;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.sga.datos.EmpleadoDao;
import com.sga.datos.TipoEmpleadoDao;
import com.sga.datos.TipoPensionDao;
import com.sga.domain.Empleado;
import com.sga.domain.TipoEmpleado;
import com.sga.domain.TipoPension;
import com.sga.services.EmpleadoService;
import com.sga.services.ReadFileService;

@Stateless
public class ReadFileServiceImpl implements ReadFileService{
	static Logger LOG = LogManager.getLogger();
	
	@Inject
	private EmpleadoDao empleadoDao;
	
	@Inject
	private TipoEmpleadoDao tipoEmpleadoDao;
	
	@Inject 
	private TipoPensionDao tipoPensionDao;
	
	@Override
	public int readExcelFile(InputStream is) {
		try {
			XSSFWorkbook libro  =  new XSSFWorkbook(is);			
			XSSFSheet hoja =  libro.getSheetAt(0);
			XSSFRow fila1 = hoja.getRow(0);
			
			for(int i = 1; i< hoja.getPhysicalNumberOfRows() ; i++) {
				int id=0;
				Empleado e =  new Empleado();
				String nombre = hoja.getRow(i).getCell(0).getStringCellValue();
				String nit  = hoja.getRow(i).getCell(1).getStringCellValue();
				int codigo =  (int) hoja.getRow(i).getCell(2).getNumericCellValue();
				String tipoP  = hoja.getRow(i).getCell(3).getStringCellValue();
				LOG.debug("IMPORTANDO DE EXCEL " + i);
				if(tipoP.equals("AFP")) {
					LOG.debug("AFP : "+ "SI");
					id=1;
				}else if(tipoP.equals("IPSFA")){
					id=2;
				}else if(tipoP.equals("CEFAFA")) {
					id=3;
				}else if(tipoP.equals("INPEP")) {
					id=4;
				}else if(tipoP.equals("BM")) {
					id=5;
				}
				//Ahora a persistir la Base de datos
				e.setApellido(nombre);
				e.setNombre("");
				e.setNit(nit);
				LOG.debug("A BUSCAR---" + codigo);
				TipoEmpleado te = tipoEmpleadoDao.buscarTipoEmpleadoByCodigo(String.valueOf(codigo));
				LOG.debug("TipoEmpleado hallado "+ te);
				if(te== null) {
					e.setTipoEmpleado(null);
				}else {
					e.setTipoEmpleado(te);
				}				
				TipoPension tp =  tipoPensionDao.buscarrTipoPensionById(new TipoPension(id));
				if(tp == null) {
					e.setTipoPension(null);
				}else{
					e.setTipoPension(tp);
					
				};
				Empleado temp  = empleadoDao.buscarPorNit(nit);
				if(temp == null) {
					 empleadoDao.insertEmpleado(e);
					//En caso de ser diferente de Nulo ese dato no se insertará
				}
			}	
			return 1; //1 es true
			
		} catch (IOException e) {
			//return 1; //Si devolvemos 1 algo falló
			//throw new ValidatorException(new FacesMessage(FacesMessage.SEVERITY_FATAL, "AVISO", "Hubieron errores en la carga"));
			e.printStackTrace(System.out);
			return 0;
		}
	}

}
