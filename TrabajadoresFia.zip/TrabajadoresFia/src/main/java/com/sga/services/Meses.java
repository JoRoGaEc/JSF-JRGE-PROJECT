package com.sga.services;

public enum Meses {
	ENERO, FEBRERO, MARZO, ABRIL , MAYO,JUNIO, JULIO, AGOSTO, SEPTIEMBRE, OCTUBRE, NOVIEMBRE, DICIEMBRE 
}
