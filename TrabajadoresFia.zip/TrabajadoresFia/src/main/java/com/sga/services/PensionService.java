package com.sga.services;

import com.sga.domain.Empleado;
import com.sga.domain.Pension;
import com.sga.domain.TipoPension;

public interface PensionService {
	public int guardarDatosPension(Pension pension);
}
