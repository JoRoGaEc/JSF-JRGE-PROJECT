package com.sga.services;

import java.util.List;

import com.sga.domain.TipoPago;

public interface TipoPagoService {

	public abstract TipoPago recuperarTipoPago(int id);
}
