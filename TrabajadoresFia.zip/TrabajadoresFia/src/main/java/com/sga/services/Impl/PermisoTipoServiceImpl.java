package com.sga.services.Impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.PermisoTipoDao;
import com.sga.domain.PermisoPago;
import com.sga.services.PermisoTipoService;


@Stateless
public class PermisoTipoServiceImpl implements PermisoTipoService{

	@Inject
	private PermisoTipoDao permisoTipoDao;
	
	@Override
	public PermisoPago buscarPermisoById(int id) {
		return permisoTipoDao.recuperarPermisoTipo(id);
	}

	
	
}
