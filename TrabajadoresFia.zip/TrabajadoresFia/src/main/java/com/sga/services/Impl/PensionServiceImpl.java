package com.sga.services.Impl;

import javax.ejb.Stateless;
import javax.inject.Inject;

import com.sga.datos.PensionDao;
import com.sga.domain.Pension;
import com.sga.services.PensionService;

@Stateless
public class PensionServiceImpl implements PensionService{

	@Inject
	private PensionDao pensionDao;
	
	@Override
	public int guardarDatosPension(Pension pension) {
		pensionDao.guardarDatosPension(pension);
		return 0;
	}

	
}
