package com.sga.services;

import java.util.List;

import com.sga.domain.Empleado;

public interface ReportesService {

	public abstract List<Empleado> empleadosByYear(int anio);
	
	public abstract Empleado  empleadoParaBoleta(int id);
}
